module.exports = {
  BOT_TOKEN: "8160473614:AAExoevgRAUGM5LwHk_eZpbZqoPdU_pDn3w",
    allowedDevelopers: ['8178163081'], // ID
};