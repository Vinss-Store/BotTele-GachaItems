const fs = require('fs')
const chalk = require('chalk')

global.baileys = require('@whiskeysockets/baileys') 
global.adiwajshing = require('@adiwajshing/baileys') 

global.gr = 'https://chat.whatsapp.com/-' // Ubah jadi grup lu
global.ig = '-' // ubah aja
global.email = '-@gmail.com' //bebas
global.region = 'indonesia' // bebas
//—————「 Set Nama Own & Bot 」—————//
global.ownername = 'kreyuk' //ubah jadi nama mu, note tanda ' gausah di hapus!
//=================================================//
global.owner = ['62895433590601'] // ubah aja pake nomor lu

//--------Jika Tidak Ada Apikey----------
global.noapikey = `
Apikey belum dipasang, silakan ambil apikey dari situs https://xzn.wtf

Cara Pemasangan Apikey
1. Buka file config.js
2. Cari global.wtf
3. ubah "YOUR_APIKEY_HERE" menjadi apikey yang diperoleh
`
//-----------------------------------
global.botname = 'Kreyuk' //ubah jadi nama bot mu, note tanda ' gausah di hapus!
global.packname = 'Bot Whatsapp' // ubah aja ini nama sticker
global.author = '© kreyuk' // ubah aja ini nama sticker
global.prefa = ['','!','.',',','🐤','🗿']
global.sessionName = 'session' //Gausah Juga
global.sp = '⭔' // Gausah Juga
global.wlcm = []
global.wlcmm = []
global.wait = 'Sedang Diproses...'

global.wtf = 'YOUR_APIKEY_HERE' // ubah yang ada didalam tanda petik ini jadi apikey lu
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 10
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})