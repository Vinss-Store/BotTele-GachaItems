const chalk = require("chalk")
const fs = require("fs")

//owmner v card
//domain && apikey && capikey && egg sesuai panel klian ya
// subrek channel DzakkyOfficial
global.owner = ['6285189248813'] //ur owner number
global.ownernomer = "6285189248813" //ur owner number2
global.ownername = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘" //ur owner name
global.ytname = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘" //ur yt chanel name
global.socialm = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘" //ur github or insta name
global.location = "Arab Saudi" //ur location
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = '_' // isi dengan domain panel lu
global.apikey = '_' // Isi Apikey Plta Lu
global.capikey = '_' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location

//new
global.ownergc = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘"
global.botname = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘"
global.ownerNumber = ["6285189248813@s.whatsapp.net"]
global.ownerweb = "_"
global.themeemoji = '🪀'
global.wm = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘"
global.packname = "𝐗𝐄𝐍𝐎𝐎 𝟒𝐘"
global.author = "AnanOfficiaL\n\n"
global.prefa = ['','!','.','#','&']
global.sessionName = 'session'
global.tekspushkon = ''
global.keyopenai ='iigf'

global.limitawal = {
    premium: "Infinity",
    free: 5
}

//media target
global.thumb = { url: 'https://img101.pixhost.to/images/599/556060386_skyzopedia.jpg' }//ur thumb pic
global.defaultpp = 'https://img101.pixhost.to/images/599/556060386_skyzopedia.jpg' //default pp wa

//messages
global.mess = {
    selesai: 'Done Bg!!', 
    owner: 'Khusus Ownerku Yach🤬',
    private: 'Khusus Chat Private',
    group: 'Khusus Chat Di Group',
    wait: 'Sebentar..',
}

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
