hallo temen temen saya Rafael selaku creator bot ini menghimbau agar script ini jangan di jual, karena script ini free dari rafael

Tqto: 
siputzx : base
Rafael : creator + fix 
kiicode : penyedia api
qioo : penyedia api
sanjaya : orang baik

saya sangat menghargai tindakan teman teman jika tidak menjual script ini, terima kasih🖕🖕🙏🙏