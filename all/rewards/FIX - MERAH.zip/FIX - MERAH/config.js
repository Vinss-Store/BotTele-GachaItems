// config.js
module.exports = {
    TELEGRAM_TOKEN: '8068772257:AAFltbbJle93PxQyV6NJ0Ip9rTvuIH99kYs',
    OWNER_ID: 7149711596, // Ganti dengan ID Telegram kamu
    CHANNEL_ID: '@allinfopixel', // Contoh: @infobotkeren
    PROFILE_PHOTO_URL: 'https://files.catbox.moe/gsyfb0.jpg', // Ganti dengan URL gambar kamu
    EMAIL_SENDER: 'mmaakklleehh@gmail.com', // Email Sender
    EMAIL_PASSWORD: '@Farkyy238', // App Password 16 digit
    COOLDOWN_DURATION: 300000, // 5 menit (300000 ms)
    MT_FILE: 'mt_texts.json',
    PREMIUM_FILE: 'premium_users.json',
    // --- File Database Lokal ---
    USER_DB: 'users.json',
    HISTORY_DB: 'history.json',
    BANNED_GROUP_DB: 'banned_groups.json',
    SETTINGS_DB: 'settings.json'
};