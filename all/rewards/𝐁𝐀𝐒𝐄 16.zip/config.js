module.exports = {
  BOT_TOKEN: "7605944119:AAE8P9rXFHg6nzZxd-R9_jRygO3cHO7-lys",
    allowedDevelopers: ['7417451868'], // ID
};