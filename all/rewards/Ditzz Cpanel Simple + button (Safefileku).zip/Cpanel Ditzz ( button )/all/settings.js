require("./module")

global.owner = "6282267754523"
global.namabot = "Vinss Botz"
global.namaCreator = "Vinss Store"
global.autoJoin = false
global.antilink = false
global.wm = 'Vinss Bot'
/* Apikey Mau Pedia*/

global.api_key = "x7eEsjntUuudcKhiLnAHJUWVhEPyZqxBfJFERQDAeFbUhBgQDGPV0o1AFOkrdQRe"//@DitzzXploit
global.api_id = "V0zOKyXKQ6ATKWXG"//@DitzzXploit
global.secret = "d)i#t#zz#x#pl#o#i#t"//@DitzzXploit

/* Batas apikey Maupedia */
global.codeInvite = "CswK4kvQD1u7SfSmsYfMHZ"
global.domain = '-' // Isi Domain Lu
global.apikey = '-' // Isi Apikey Plta Lu
global.capikey = '-' // Isi Apikey Pltc Lu
global.eggsnya = '15' // id eggs yang dipakai
global.location = '1' // id location
global.thumb = fs.readFileSync("./thumb.png")
global.audionya = fs.readFileSync("./all/sound.mp3")
global.qris = fs.readFileSync("./qris.png")
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "Sticker By Vinss"
global.jumlah = "5"

let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})