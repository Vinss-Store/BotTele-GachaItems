/* 

=======================================

SCRIPT BOT CPANEL TELE @REZISTORE
aman anti backdoor (gunakan untuk hal baik!!)
=======================================

*/
const settings = {
  owner: '7680882337', // ganti id telegram lu
  token: '7395050621:AAHiK6G4fkFKS-NfgGy932H2fx4GYGjwDZQ', // Token Bot Lu
  domain: 'domain_lu', // domain
  plta: 'ptla_lu', // plta yang sesuai
  pltc: 'pltc_lu', // pltc yang sesuai
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15',
};

module.exports = settings;