require('./config')

const axios = require('axios');
const fs = require('fs');
const {
	getGroupAdmins,
	jsonformat,
	runtime,
	sleep
} = require('./db/function')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, generateWAMessageFromContent, proto, getBinaryNodeChildren, generateWAMessageContent, generateWAMessage, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys');

module.exports = vinss = async (vinss, m, chatUpdate, store) => { try {
var body = (m.mtype === 'conversation') ? m.message.conversation: (m.mtype == 'imageMessage') ? m.message.imageMessage.caption: (m.mtype == 'videoMessage') ? m.message.videoMessage.caption: (m.mtype == 'extendedTextMessage') ? m.message.extendedTextMessage.text: (m.mtype == 'buttonsResponseMessage') ? m.message.buttonsResponseMessage.selectedButtonId: (m.mtype == 'listResponseMessage') ? m.message.listResponseMessage.singleSelectReply.selectedRowId: (m.mtype == 'templateButtonReplyMessage') ? m.message.templateButtonReplyMessage.selectedId: (m.mtype === 'messageContextInfo') ? (m.message.buttonsResponseMessage?.selectedButtonId || m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text): ''
var budy = (typeof m.text == 'string' ? m.text: '')
const isCmd = body.startsWith(prefix)
const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase(): ''
const args = body.trim().split(/ +/).slice(1)
const botId = await vinss.decodeJid(vinss.user.id)
const botNumber = botId.split('@')[0]
const ownId = ownNumb.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
const ownNumber = ownNumb.replace(/[^0-9]/g, '')
const dtext = args.join(" ")
const quoted = m.quoted ? m.quoted: m
const groupMetadata = m.isGroup ? await vinss.groupMetadata(m.chat).catch(e => {}): ''
const groupName = m.isGroup ? groupMetadata.subject: ''
const participants = m.isGroup ? await groupMetadata.participants: ''
const groupAdmins = m.isGroup ? await getGroupAdmins(participants): ''
const isGroupAdmins = m.isGroup ? groupAdmins.includes(m.sender): false
const isBotGroupAdmins = m.isGroup ? groupAdmins.includes(botId): false
var isAuthor = autOwn.replace(/[^0-9]/g, '').includes(m.sender.split("@")[0])
var isOwner = ownId.includes(m.sender)
var isMe = botId.includes(m.sender)
var isCreator = isOwner || isAuthor || isMe

const reply = (text) => {
	vinss.sendMessage(m.chat, {text: text.toString()}, {quoted: m})
}

let autoReplyEnabled = false;
let groupOnlyMode = false;

// Anti-Link WhatsApp Group Feature
if (m.isGroup && !isGroupAdmins && isBotGroupAdmins) {
    const linkRegex = /(https?:\/\/chat\.whatsapp\.com\/[^\s]+)/g;
    if (linkRegex.test(body)) {
        reply("Link grup WhatsApp tidak diizinkan di grup ini!");
        // Hapus pesan yang berisi link grup
        await vinss.sendMessage(m.chat, { delete: m.key });
    }
}

if (autoReplyEnabled && !isCmd && m.isGroup) {
    reply('Walaikumsallam .');
}

// Initialize player data
const players = {}

function initializePlayer(playerId) {
    players[playerId] = {
        name: 'Player',
        level: 1,
        health: 100,
        attack: 10,
        defense: 5,
        xp: 0,
        inventory: [],
        gold: 0
    }
}

async function listbut2(chat, teks, listnye, m) {
let msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
"messageContextInfo": {
"deviceListMetadata": {},
"deviceListMetadataVersion": 2
},
interactiveMessage: proto.Message.InteractiveMessage.create({
contextInfo: {
mentionedJid: [m.sender],
forwardingScore: 999999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterName: 'Join For More Info',
serverMessageId: null,
}
},
body: proto.Message.InteractiveMessage.Body.create({
text: teks
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: `By Vinss`
}),
header: proto.Message.InteractiveMessage.Header.create({
title: ``,
thumbnailUrl: "",
gifPlayback: true,
subtitle: "",
hasMediaAttachment: true,
...(await prepareWAMessageMedia({
document: fs.readFileSync('./lib/vinss.png'),
mimetype: "image/png",
fileLength: 99999999999999,
jpegThumbnail: fs.readFileSync('./lib/vinss.png'),
fileName: "Vinss Boyz",
}, {
upload: vinss.waUploadToServer
}))
}),
gifPlayback: true,
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
buttons: [
{
"name": "single_select",
"buttonParamsJson": JSON.stringify(listnye)
}],
}), })}
}}, {quoted: m})
await vinss.relayMessage(msg.key.remoteJid, msg.message, {
messageId: msg.key.id
})
}

if (command) {
	vinss.readMessages([m.key])
	console.log()
	console.log(`${m.isGroup ? '\x1b[0;32mGC\x1b[1;32m-CMD' : '\x1b[1;32mPC-CMD'} \x1b[0m[ \x1b[1;37m${command} \x1b[0m] at \x1b[0;32m${calender}\x1b[0m\n› ${m.chat}\n› from; \x1b[0;37m${m.sender.split('@')[0]}\x1b[0m${m.pushName ? ', '+m.pushName : ''}\n› in; \x1b[0;32m${m.isGroup ? groupName : 'Personal Chat'}\x1b[0m`)
}


switch (command) {

case 'menu': case 'help':{
let menunya = `
╔════《 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢 》══════╗
╠ *Nama* : ${m.pushName ? ', '+m.pushName : ''}
╚═══════《✧》════════╝`
const bet = {
title: "MENU BY VINSS BOYZ",
sections: [
{
title: `Silahkan Pilih Menu Bot`, 
highlight_label: `Populer`,
rows: [
{
title: "Menu Bot",
description: "Menampilkan Menu Bot",
id: `${prefix}menubot`,
},
{
title: " Menu Group ",
description: "Menampilkan Menu Group",
id: `${prefix}menugroup`,
},
{
title: "Menu Owner",
description: "Menampilkan Menu Owner",
id: `${prefix}menuowner`,
},
]},
]};

listbut2(m.chat, menunya, bet, m)
}
break

case 'runtime': case 'test':
reply('Runtime; '+runtime(process.uptime()))
break // (?); runtime bot

case 'owner': case 'botowner':
let ownContact = {
displayName: "Contact", contacts: [{displayName: ownName, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+ownName+";;;\nFN:"+ownName+"\nitem1.TEL;waid="+ownNumber+":"+ownNumber+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); kontak owner
let soContact = await vinss.sendMessage(m.chat, {contacts: ownContact}, {quoted: m})
setTimeout(() => {vinss.sendMessage(m.chat, {delete: soContact.key})}, 20000)
break

case 'script': case 'sc': // hargai penerbit!
let soScript = await vinss.sendMessage(m.chat, {text: 'https://whatsapp.com/channel/0029VaF4IIt1CYoaRgoOaX2i', contextInfo: {forwardingScore: 2, isForwarded: true}}, {quoted: m})
setTimeout(() => {vinss.sendMessage(m.chat, {delete: soScript.key})}, 10000)
break // (?); bot script

//Owner Menu
case 'shutdown':
    if (m.sender !== ownNumber) return reply('This command is restricted to the bot owner.');

    reply('Shutting down bot...');
    setTimeout(() => process.exit(0), 1000);
    break;

const axios = require('axios');

case 'menfess': {
    if (!args[0] || !args[1]) {
        return reply(`Cara penggunaan: \n*!menfess [nomor tujuan] | [pesan menfess]*\nContoh: !menfess 6281234567890 | Halo, ini pesan anonim.`);
    }
    let splitText = dtext.split('|');
    let targetNumber = splitText[0].trim().replace(/[^0-9]/g, '') + '@s.whatsapp.net';
    let messageText = splitText[1] ? splitText[1].trim() : '';

    if (messageText === '') return reply('Pesan menfess tidak boleh kosong.');
    await vinss.sendMessage(targetNumber, {
        text: `Pesan Menfess: \n\n${messageText}`,
        footer: 'Ini adalah pesan anonim yang dikirim melalui bot.'
    }, { quoted: m });
    reply(`Pesan menfess berhasil dikirim ke ${targetNumber.split('@')[0]}`);
    setTimeout(async () => {
        await vinss.sendMessage(targetNumber, {
            text: `Terima kasih telah mengirim pesan. Kami akan segera membalasnya!`,
        });
    }, 5000);
}
break;

case 'setbotprofile':
    if (!isOwner) return reply('Perintah ini hanya untuk owner!');
    if (!m.message.imageMessage) return reply('Kirim gambar untuk dijadikan foto profil!');

    let image = await vinss.downloadMediaMessage(m.message.imageMessage);
    await vinss.updateProfilePicture(botId, image);
    reply('Foto profil bot berhasil diubah!');
    break;

case 'kickall':
    if (!m.isGroup) return reply('Perintah ini hanya untuk digunakan di grup!');
    if (!isGroupAdmins) return reply('Hanya admin yang bisa menggunakan perintah ini!');
    if (!isOwner) return reply('Perintah ini hanya untuk owner!');
    
    let allParticipants = groupMetadata.participants.map(p => p.id);
    let nonAdmins = allParticipants.filter(p => !groupAdmins.includes(p)); 
    
    if (nonAdmins.length === 0) return reply('Tidak ada anggota non-admin untuk di-kick.');
    
    for (let member of nonAdmins) {
        await vinss.groupParticipantsUpdate(m.chat, [member], 'remove');
        await sleep(500); 
    }
    reply('Semua anggota non-admin berhasil dikeluarkan!');
    break;

case 'autoreply':
if (!isOwner) return reply('Perintah ini hanya untuk owner!');
autoReplyEnabled = !autoReplyEnabled;
reply(`Auto-reply ${autoReplyEnabled ? 'diaktifkan' : 'dinonaktifkan'}.`);
break;

case 'getcase': case 'case': try {
	if (!isCreator) return reply('not_owner')
	if (!dtext) return reply('nama_case?')
	const getCase = (dtext) => {
		return "case " + `'${dtext}'` + require('fs').readFileSync("vinssboyz.js").toString().split('case \''+ dtext +'\'')[1].split("break")[0]+"break"
	} // (?); ngambil case
	reply(getCase(dtext))
} catch {
	reply('not_found')
}
break

case 'grouponly':
    if (!isOwner) return reply('Perintah ini hanya untuk owner!');
    
    groupOnlyMode = !groupOnlyMode;
    reply(`Mode grup saja ${groupOnlyMode ? 'diaktifkan' : 'dinonaktifkan'}.`);
    break;

case 'grouplist': case 'listgrup': case 'listgc': case 'idgrup':
if (!isCreator) return reply('not_owner')
let getGroups = await vinss.groupFetchAllParticipating()
let gclish = Object.entries(getGroups).slice(0).map((entry) => entry[1])
let gclist = gclish.map(v => v.id)
if (gclist.length > 20) return reply(jsonformat(gclist))
let gctext = `Daftar Chat grup; (total: ${gclist.length})`
for (let a of gclist) {
	let mdata = await vinss.groupMetadata(a)
	gctext += `\n\nSubject: *${mdata.subject}*\nTotal peserta: ${mdata.participants.length}\niD: ${mdata.id}`
} // (?); daftar chat grup
reply(gctext)
break

case 'msendchat': case 'pushkontak':
if (!isCreator) return reply('not_owner')
if (!m.isGroup) return reply('group_only')
if (!dtext) return reply('Ex: !pushkontak teksnya')
	let pkDetect = await vinss.groupMetadata(m.chat)
	if (pkDetect.participants.length > 200) return reply('member maksimal; 200')
	reply('Mengirim pesan ke '+pkDetect.participants.length+' kontak..')
	for (let a of pkDetect.participants) {
	vinss.sendMessage(a.id, {text: dtext})
	await sleep(500)
} // (?); kirim pesan ke semua peserta grup
reply('Group: *'+pkDetect.subject+'*\nTotal peserta; '+pkDetect.participants.length+'\n\nText;\n'+dtext+'\n\ndelay: 500ms\nmsg_success')
break

case 'msendchat2': case 'pushkontak2':
if (!isCreator) return reply('not_owner')
	let phkid = dtext.split('|')[0]
	let phktxt = dtext.split('|')[1]
if (!phkid) return reply('Ex: !pushkontak2 idGrup|text')
if (!phktxt) return reply('Ex: !pushkontak2 idGrup|text')
	let pk2Detect = await vinss.groupMetadata(phkid)
	if (pk2Detect.participants.length > 200) return reply('member maksimal; 200')
	reply('Mengirim pesan ke '+pk2Detect.participants.length+' kontak..')
	for (let a of pk2Detect.participants) {
	vinss.sendMessage(a.id, {text: phktxt})
	await sleep(500)
} // (?); kirim pesan ke semua peserta grup (id)
reply('Group: *'+pk2Detect.subject+'*\nTotal peserta; '+pk2Detect.participants.length+'\n\nText;\n'+phktxt+'\n\ndelay: 500ms\nmsg_success')
break

//Group Menu
case 'promote':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!m.mentionedJid.length) return reply('Mention at least one user to promote.')
for (let participant of m.mentionedJid) {
    await vinss.groupParticipantsUpdate(m.chat, [participant], 'promote')
}
reply('Successfully promoted members to admin!')
break

case 'demote':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!m.mentionedJid.length) return reply('Mention at least one user to demote.')

for (let participant of m.mentionedJid) {
    await vinss.groupParticipantsUpdate(m.chat, [participant], 'demote')
}
reply('Successfully demoted members from admin!')
break

case 'mute':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
await vinss.groupSettingUpdate(m.chat, 'announcement')
reply('Group has been muted. Only admins can send messages now!')
break

case 'unmute':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
await vinss.groupSettingUpdate(m.chat, 'not_announcement')
reply('Group has been unmuted. All members can send messages now!')
break

case 'getgroupinfo':
if (!m.isGroup) return reply('This command can only be used in a group.')
let groupInfo = await vinss.groupMetadata(m.chat)
let groupAdmins = groupInfo.participants.filter(p => p.admin).map(p => p.id)
let infoText = `*Group Info*\nName: ${groupInfo.subject}\nID: ${groupInfo.id}\nCreated At: ${new Date(groupInfo.creation * 1000).toLocaleString()}\nAdmins: ${groupAdmins.length}\nMembers: ${groupInfo.participants.length}`
reply(infoText)
break

case 'setannouncement':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!args[0]) return reply('Please provide the announcement message.')

let announcementMessage = args.join(' ')
await vinss.sendMessage(m.chat, {text: `📢 *Announcement:* ${announcementMessage}`}, {quoted: m})
reply('Announcement sent successfully!')
break

case 'welcomemsg':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!args[0]) return reply('Please provide a welcome message template.')

global.welcomeMessage = args.join(' ')
reply('Welcome message set successfully!')
break

case 'getinvitelink':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')

let inviteLink = await vinss.groupInviteCode(m.chat)
reply(`Here is your invite link:\nhttps://chat.whatsapp.com/${inviteLink}`)
break

case 'revokeinvitelink':
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')

await vinss.groupRevokeInvite(m.chat)
reply('Group invite link revoked successfully!')
break

case 'creategroup': 
if (!isCreator) return reply('You are not authorized to use this command.')
if (!args[0]) return reply('Provide a group name.')
if (!m.mentionedJid.length) return reply('Mention at least one user to add to the group.')

let groupName = args.join(' ')
let participants = m.mentionedJid
let newGroup = await vinss.groupCreate(groupName, participants)
reply(`Group created successfully!\nName: ${newGroup.subject}\nID: ${newGroup.id}`)
break

case 'add': 
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!m.mentionedJid.length) return reply('Mention at least one user to add.')

for (let participant of m.mentionedJid) {
    await vinss.groupParticipantsUpdate(m.chat, [participant], 'add')
}
reply('Successfully added new members!')
break

case 'remove': 
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!m.mentionedJid.length) return reply('Mention at least one user to remove.')

for (let participant of m.mentionedJid) {
    await vinss.groupParticipantsUpdate(m.chat, [participant], 'remove')
}
reply('Successfully removed members!')
break

case 'setgroupname': 
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!args[0]) return reply('Please provide a new group name.')
await vinss.groupUpdateSubject(m.chat, args.join(' '))
reply('Group name updated successfully!')
break

case 'setgroupdesc': 
if (!m.isGroup) return reply('This command can only be used in a group.')
if (!isGroupAdmins) return reply('You need to be a group admin to use this command.')
if (!args[0]) return reply('Please provide a new group description.')

await vinss.groupUpdateDescription(m.chat, args.join(' '))
reply('Group description updated successfully!')
break

case 'getcontact': case 'getkontak':
if (!m.isGroup) return reply('group_only')
if (!(isGroupAdmins || isCreator)) return reply('admin_only')
huhuhs = await vinss.sendMessage(m.chat, {
    text: `Grup; *${groupMetadata.subject}*\nTotal peserta; *${participants.length}*`
}, {quoted: m, ephemeralExpiration: 86400})
await sleep(1000) // (?); mengirim kontak seluruh member
vinss.sendContact(m.chat, participants.map(a => a.id), huhuhs)
break

case 'savekontak': case 'svkontak':
if (!m.isGroup) return reply('group_only')
if (!(isGroupAdmins || isCreator)) return reply('admin_only')
let cmiggc = await vinss.groupMetadata(m.chat)
let orgiggc = participants.map(a => a.id)
vcard = ''
noPort = 0
for (let a of cmiggc.participants) {
    vcard += `BEGIN:VCARD\nVERSION:3.0\nFN:[${noPort++}] +${a.id.split("@")[0]}\nTEL;type=CELL;type=VOICE;waid=${a.id.split("@")[0]}:+${a.id.split("@")[0]}\nEND:VCARD\n`
} // (?); mengimpor kontak seluruh member - save
let nmfilect = './contacts.vcf'
reply('Mengimpor '+cmiggc.participants.length+' kontak..')
require('fs').writeFileSync(nmfilect, vcard.trim())
await sleep(2000)
vinss.sendMessage(m.chat, {
    document: require('fs').readFileSync(nmfilect), mimetype: 'text/vcard', fileName: 'Contact.vcf', caption: 'Group: *'+cmiggc.subject+'*\nParticipants total: *'+cmiggc.participants.length+'*'
}, {ephemeralExpiration: 86400, quoted: m})
require('fs').unlinkSync(nmfilect)
break

case 'sendkontak': case 'kontak':
if (!m.isGroup) return reply('group_only')
if (!m.mentionedJid[0]) return reply('Ex; .kontak @tag|nama')
let snTak = dtext.split(' ')[1] ? dtext.split(' ')[1] : 'Contact'
let snContact = {
	displayName: "Contact", contacts: [{displayName: snTak, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+snTak+";;;\nFN:"+snTak+"\nitem1.TEL;waid="+m.mentionedJid[0].split('@')[0]+":"+m.mentionedJid[0].split('@')[0]+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); send kontak
vinss.sendMessage(m.chat, {contacts: snContact}, {ephemeralExpiration: 86400})
break

case 'sendkontag': case 'kontag':
if (!m.isGroup) return reply('group_only')
if (!(isGroupAdmins || isCreator)) return reply('admin_only')
if (!m.mentionedJid[0]) return reply('Ex; .kontak @tag|nama')
let sngTak = dtext.split(' ')[1] ? dtext.split(' ')[1] : 'Contact'
let sngContact = {
	displayName: "Contact", contacts: [{displayName: sngTak, vcard: "BEGIN:VCARD\nVERSION:3.0\nN:;"+sngTak+";;;\nFN:"+sngTak+"\nitem1.TEL;waid="+m.mentionedJid[0].split('@')[0]+":"+m.mentionedJid[0].split('@')[0]+"\nitem1.X-ABLabel:Ponsel\nEND:VCARD"}]
} // (?); send kontak - hidetag
vinss.sendMessage(m.chat, {contacts: sngContact, mentions: participants.map(a => a.id)}, {ephemeralExpiration: 86400})
break

case 'menubot': {
reply(`
╔════《 𝗨𝗦𝗘𝗥 𝗜𝗡𝗙𝗢 》═══╗
╠ *Nama* : ${m.pushName ? m.pushName : 'Tanpa Nama'}
╚═══════《✧》════════╝
╔════《 𝗕𝗢𝗧 》══════╗
╠${prefix}profile
╠${prefix}claim
╠${prefix}buy [item] (nominal)
╠${prefix}transfer
╠${prefix}leaderboard
╠${prefix}request (text)
╠${prefix}react (emoji)
╠${prefix}tagme
╠${prefix}runtime
╠${prefix}totalfitur
╠${prefix}ping
╠${prefix}afk
╠${prefix}rvo (reply pesan viewone)
╠${prefix}inspect (url gc)
╠${prefix}addmsg
╠${prefix}delmsg
╠${prefix}getmsg
╠${prefix}listmsg
╠${prefix}q (reply pesan)
╠${prefix}menfes (62xxx|nama samaran)
╚═══════《✧》════════╝`)
}
			break

default:

if (budy.startsWith('>')) {
    if (!isCreator) return
    try {
        let evaled = await eval(budy.slice(2))
        if (typeof evaled !== 'string') evaled = require('util').inspect(evaled)
        await reply(evaled)
    } catch (err) {
        await reply(String(err))
    }
}

if (budy.startsWith('$')) {
    if (!isOwner) return
    require("child_process").exec(budy.slice(2), (err, stdout) => {
        if (err) return reply(`${err}`)
        if (stdout) return reply(stdout)
    })
}

}
	} catch (err) {
		const errId = isOwner ? m.chat : ownNumb.replace(/[^0-9]/g, '')+'@s.whatsapp.net'
		vinss.sendMessage(errId, {text: require('util').format(err)}, {quoted: m})
		console.log('\x1b[1;31m'+err+'\x1b[0m')
	}
}


let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file)
	console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
	delete require.cache[file]
	require(file)
})