global.d = new Date();
global.calender = d.toLocaleDateString('id');

global.prefix = "."; // Command prefix
global.ownNumb = "+6282267754523"; // Nomor owner
global.ownName = "Space Boyz Terverifikasi Whatsapp"; // Nama owner

global.my = 
	yt = "https://youtube.com/c/VinssBotz"; // Link Yt Lu
	gh = "https://github.com/VinssBotz"; // Link Gh Lu
	gc = "https://chat.whatsapp.com/GbvXiqhlb4AJ0n109pXXmJ";
	ch = "https://whatsapp.com/channel/0029VaF4IIt1CYoaRgoOaX2i";

global.apiKey = "https://api.xyzen.tech"; // Add the API key here

/* Alpha1.0-main
nomer owmer satu aja, jangan d kasih duoble.
prefix nya single, ga multi.
prefix default "." (titik) kalo mau ganti ganti aja.
version; 1.0 */

// #@whiskeysockets/baileys ^6.3.0
global.autOwn = "req(62-8S57547ms11).287p";
let file = require.resolve(__filename);
require('fs').watchFile(file, () => {
	require('fs').unwatchFile(file);
	console.log('\x1b[0;32m' + __filename + ' \x1b[1;32mupdated!\x1b[0m');
	delete require.cache[file];
	require(file);
});