const settings = {
  ownerName: 'Vinss Boyz', // Ganti dengan nama owner lu
  botToken: '7901282943:AAEZFsvnLXvCGs__v3QSYtBdmvdw9jGNFAk', // Ganti dengan token bot Telegram lu
  owner: '7529831376', //OWNER user id

};

module.exports = settings;
