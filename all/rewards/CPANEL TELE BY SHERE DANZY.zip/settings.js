/*
By Danzy
Buy No Enc? Pm
62881025599696
*/

const settings = {
  token: '7875239085:AAEqol0wL1hRcFCaz94bDqcVp79NSBZA7_o',
  adminId: '6347609045', 
  pp: 'https://img101.pixhost.to/images/652/558825854_skyzopedia.jpg',
urladmin: 'https://t.me/DanzyTamvan',
  pp: 'https://img101.pixhost.to/images/652/558825854_skyzopedia.jpg',
    //SERVER 1
  domain: '', // domain
  plta: '', //  plta yang sesuai
  pltc: '', // pltc yang sesuai
  
  //CREATE PANEL
  loc: '1', // Isi dengan lokasi yang diinginkan
  eggs: '15'
};

module.exports = settings;