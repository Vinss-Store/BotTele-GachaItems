const express = require('express');
const path = require('path');
const { networkInterfaces } = require('os');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.static(__dirname));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

function getLocalIP() {
    const nets = networkInterfaces();
    const results = [];
    
    for (const name of Object.keys(nets)) {
        for (const net of nets[name]) {
            if (net.family === 'IPv4' && !net.internal) {
                results.push(net.address);
            }
        }
    }
    return results;
}

app.listen(PORT, '0.0.0.0', () => {
    const localIPs = getLocalIP();
    console.log(`Server running on:`);
    console.log(`- Local: http://localhost:${PORT}`);
    localIPs.forEach(ip => {
        console.log(`- Network: http://${ip}:${PORT}`);
    });
});
