module.exports = {
  BOT_TOKEN: "7862652803:AAFBvirVxLzMiEw9flgi1jBQXuzitlfRkLE",
};