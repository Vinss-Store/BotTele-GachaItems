module.exports = {
  BOT_TOKEN: "7850157258:AAEhuwIXohAAkfMHZWv1CTKBbeWrDlZ5ar0", 
};