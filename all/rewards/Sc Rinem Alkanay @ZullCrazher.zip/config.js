module.exports = {
  OWNER_ID: ["8075532833"],
  GITHUB_TOKEN: "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",
  GITHUB_OWNER: "putraleomeko",
  GITHUB_REPO: "floids",
  GITHUB_FILE_PATH: "tokens.json",
  GITHUB_MOD_FILE_PATH: "moderators.json", 
  START_IMAGE_URL: "https://files.catbox.moe/2suo70.jpg" 
};