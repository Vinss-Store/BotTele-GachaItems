const global = {
    owner: [7703162727], // ganti jadi id mu
    botToken: "7859064029:AAGv7o2VgMyPAapVNqoEvqaoqiLgpFok50c", //isi make token bot mu
}

module.exports = global;