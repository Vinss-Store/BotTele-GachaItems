module.exports = {
modul: {
	axios: require('axios'),
	boom: require('@hapi/boom'),
	baileys: require('@whiskeysockets/baileys'), 
	chalk: require('chalk'),
	cheerio: require('cheerio'),
	child_process: require('child_process'),
	fs: require('fs'),
	fetch: require('node-fetch'),
	FormData: require('form-data'),
	FileType: require('file-type'),
	process: require('process'),
	PhoneNumber: require('awesome-phonenumber')
}
}
/*
    CREDIST !!!
        > Hw Mods [ Base ]
        > Rerez Hosting [ Developer ]

    SAYA SANGAT BERTERIMA KASIH JIKA KALIAN MEMBIARKAN CREDIT INI TANMPA MENGHAPUS ATAU MENGGANTI NYA 
    TOLONG HARGAI YAA
    
WA ME : https://wa.me/6282312436896
TE ME : https://t.me/rerez_x_hosting
YT ME : https://www.youtube.com/@RerezHosting
SALURAN WA : https://whatsapp.com/channel/0029VacxTsC8F2p5dshCmq3r
    
WOI JB KONTOL JANGAN DI JUAL BANGSAT 🤬

*/