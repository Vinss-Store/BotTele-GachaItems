/* <--! CREATED BY  LIO SATNDSR INVICTUS !-->

Telegram Developer @LIONOTDEVJS
Join Channel Info Update @CRAK_SC_DB

*/
module.exports = {
  BOT_TOKEN: "8428184194:AAHU6wUHlCpH1dtTNO2Lsx5FWKEPOJ3tqas",
  OWNER_ID: ["7619375530"],
};