const premiumUsers = [

  { id: '7619375530', expiry: 1684022400000 }, 
  
];

module.exports = premiumUsers;
