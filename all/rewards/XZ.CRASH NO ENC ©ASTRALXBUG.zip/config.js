module.exports = {
  BOT_TOKEN: "7661950236:AAFUXW90REUFxXyFNjFQ21MGeknq7Y-EnM8",
    allowedDevelopers: ['7560467538'], // ID
};