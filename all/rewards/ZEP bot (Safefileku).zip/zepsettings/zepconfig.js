module.exports = {
  tokenBot: "8271928746:AAHbgMc03bTmzdP89hoCdmv1Cr1P9e5Ccn8",
  ownerID: ["7660649422"],
  moderatorID: ["7660649422"]
};