//Py Pak Toya
module.exports = {
  BOT_TOKEN: "u Token", // Token bot Telegram
  OWNER_ID: "u Id", // ID pemilik bot
  allowedGroupIds: [-10046497217, -1004794668804, -1038084978410, -1646731020, -6061973172], // ID grup yang diizinkan
};