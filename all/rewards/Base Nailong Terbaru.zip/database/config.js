module.exports = {
  tokens: "8092747994:AAHdzh2HsMuCbq4u5xAm1Tu2FQUtkAwHVXM",  // Ubah Jadi Token Bot Mu !!!
  owner: "7537228352", // Ubah Jadi Id Mu !!!
  port: "3357", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://oline.jkt48-private.com" // Ubah Jadi Ip Vps Mu !!!
};